import json
import hashlib
import base64
import mimetypes
import os
import random
import shutil
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import wave
from dataclasses import asdict, dataclass
from pathlib import Path
from urllib.parse import urlsplit

import pygame
from PySide6.QtCore import QEasingCurve, QPropertyAnimation, QRect, Qt, QTimer, QUrl, QThread, Signal
from PySide6.QtGui import QColor, QCursor, QDesktopServices, QFont, QFontDatabase, QFontMetrics, QIcon, QImage, QKeySequence, QLinearGradient, QMovie, QPainter, QPixmap, QShortcut
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFontComboBox,
    QFormLayout,
    QFrame,
    QGraphicsOpacityEffect,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QInputDialog,
    QProgressDialog,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSlider,
    QStackedWidget,
    QTextEdit,
    QToolButton,
    QVBoxLayout,
    QWidget,
)
from mutagen import File as MutagenFile
from mutagen.flac import Picture
from mutagen.id3 import APIC, ID3, TALB, TDRC, TIT2, TPE1

try:
    from spotify import SpotifyPanel
    SPOTIFY_IMPORT_ERROR = ''
except (ImportError, OSError) as exc:
    SpotifyPanel = None
    SPOTIFY_IMPORT_ERROR = str(exc)


APP_DIR = Path(os.getenv('LOCALAPPDATA', str(Path.home()))) / 'UNDERGROUND'
STATE_PATH = APP_DIR / 'library.json'
CSS_PLUGINS_DIR = APP_DIR / 'plugins'
PROJECT_DIR = (
    Path(sys.executable).resolve().parent
    if getattr(sys, 'frozen', False)
    else Path(__file__).resolve().parent
)
RESOURCE_DIR = Path(getattr(sys, '_MEIPASS', PROJECT_DIR))
APP_LOGO_PATH = RESOURCE_DIR / 'assets' / 'underground-logo.png'
MUSIC_DIR = PROJECT_DIR / 'music'
BACKGROUNDS_DIR = PROJECT_DIR / 'backgrounds'
CURSORS_DIR = PROJECT_DIR / 'cursors'
SUPPORTED_AUDIO = {'.wav', '.mp3', '.ogg'}
MAX_AUDIO_DOWNLOAD_BYTES = 250 * 1024 * 1024
MAX_COVER_DOWNLOAD_BYTES = 15 * 1024 * 1024
ACCENTS = {
    'Violet': '#b69cff',
    'Amber': '#e5a84b',
    'Red': '#e25c5c',
    'Green': '#72b887',
    'Ice': '#72a9c8',
}
THEMES = {
    'After Hours': ('#17120f', '#211a16', '#30231d', '#fff2e4', '#c4aa96'),
    'Night Garden': ('#101813', '#18231b', '#243329', '#eff6e8', '#a8bea9'),
    'Plum Room': ('#19121a', '#251a27', '#35243a', '#f6eafa', '#c3a9c7'),
    'Obsidian': ('#171513', '#211e1a', '#2b2621', '#f4f0e9', '#b5a99d'),
}
APPEARANCE_STYLES = ('Classic', 'Liquid Glass')


def parse_color(value):
    if not isinstance(value, str):
        return None
    value = value.strip()
    if value.casefold().startswith('rgb(') and value.endswith(')'):
        value = value[4:-1]
    if ',' in value:
        try:
            red, green, blue = (int(part.strip()) for part in value.split(','))
        except (ValueError, TypeError):
            return None
        if all(0 <= channel <= 255 for channel in (red, green, blue)):
            return QColor(red, green, blue)
        return None
    color = QColor(value)
    return color if color.isValid() else None


def validate_stylesheet(stylesheet):
    if len(stylesheet.encode('utf-8')) > 256 * 1024:
        return 'Stylesheets must be smaller than 256 KB.'
    depth = 0
    quote = ''
    escaped = False
    in_comment = False
    index = 0
    while index < len(stylesheet):
        char = stylesheet[index]
        following = stylesheet[index + 1] if index + 1 < len(stylesheet) else ''
        if in_comment:
            if char == '*' and following == '/':
                in_comment = False
                index += 2
                continue
        elif quote:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == quote:
                quote = ''
        elif char == '/' and following == '*':
            in_comment = True
            index += 2
            continue
        elif char in ('"', "'"):
            quote = char
        elif char == '{':
            depth += 1
        elif char == '}':
            depth -= 1
            if depth < 0:
                return 'Stylesheet has a closing brace without a matching opening brace.'
        index += 1
    if in_comment:
        return 'Stylesheet has an unclosed comment.'
    if quote:
        return 'Stylesheet has an unclosed quoted value.'
    if depth:
        return 'Stylesheet has an unclosed rule block.'
    return ''


class DirectAudioDownloadWorker(QThread):
    progress_changed = Signal(int)
    completed = Signal(str, str)

    def __init__(self, url, parent=None):
        super().__init__(parent)
        self.url = url

    def run(self):
        temporary_path = ''
        try:
            parsed_url = urlsplit(self.url)
            if parsed_url.scheme != 'https' or not parsed_url.hostname or parsed_url.username or parsed_url.password:
                raise ValueError('Enter a direct HTTPS audio-file URL.')
            request = urllib.request.Request(
                self.url,
                headers={'User-Agent': 'UNDERGROUND Desktop Player/1.0'},
            )
            with urllib.request.urlopen(request, timeout=30) as response:
                final_url = urlsplit(response.geturl())
                if final_url.scheme != 'https':
                    raise ValueError('Audio downloads must remain on HTTPS.')
                content_type = response.headers.get_content_type().casefold()
                extension = Path(final_url.path).suffix.casefold()
                extensions_by_type = {
                    'audio/mpeg': '.mp3',
                    'audio/mp3': '.mp3',
                    'audio/x-mpeg': '.mp3',
                    'audio/wav': '.wav',
                    'audio/x-wav': '.wav',
                    'audio/vnd.wave': '.wav',
                    'audio/ogg': '.ogg',
                    'audio/x-ogg': '.ogg',
                    'application/ogg': '.ogg',
                }
                if extension not in SUPPORTED_AUDIO:
                    extension = extensions_by_type.get(content_type, '')
                if extension not in SUPPORTED_AUDIO:
                    raise ValueError('The URL did not provide a supported MP3, WAV, or OGG audio file.')
                if not content_type.startswith('audio/') and content_type not in ('application/ogg', 'application/octet-stream'):
                    raise ValueError(f'The URL returned {content_type or "an unknown content type"}, not audio.')
                raw_length = response.headers.get('Content-Length')
                total_bytes = int(raw_length) if raw_length and raw_length.isdigit() else 0
                if total_bytes > MAX_AUDIO_DOWNLOAD_BYTES:
                    raise ValueError('The audio file is larger than the 250 MB download limit.')

                download_dir = APP_DIR / 'downloads'
                download_dir.mkdir(parents=True, exist_ok=True)
                with tempfile.NamedTemporaryFile(
                    prefix='underground-download-',
                    suffix=extension,
                    dir=download_dir,
                    delete=False,
                ) as destination:
                    temporary_path = destination.name
                    downloaded_bytes = 0
                    while True:
                        if self.isInterruptionRequested():
                            raise InterruptedError('Download canceled.')
                        chunk = response.read(1024 * 1024)
                        if not chunk:
                            break
                        downloaded_bytes += len(chunk)
                        if downloaded_bytes > MAX_AUDIO_DOWNLOAD_BYTES:
                            raise ValueError('The audio file is larger than the 250 MB download limit.')
                        destination.write(chunk)
                        self.progress_changed.emit(
                            int(downloaded_bytes * 100 / total_bytes) if total_bytes else -1
                        )
                if downloaded_bytes == 0:
                    raise ValueError('The URL returned an empty audio file.')
                self.completed.emit(temporary_path, '')
        except (OSError, ValueError, urllib.error.URLError, InterruptedError) as exc:
            if temporary_path:
                Path(temporary_path).unlink(missing_ok=True)
            self.completed.emit('', str(exc))


class OnlineMetadataLookupWorker(QThread):
    completed = Signal(object, str)
    _last_request_time = 0.0

    def __init__(self, title, artist, parent=None):
        super().__init__(parent)
        self.title = title
        self.artist = artist

    def run(self):
        try:
            delay = 1.1 - (time.monotonic() - OnlineMetadataLookupWorker._last_request_time)
            if delay > 0:
                time.sleep(delay)
            title = self.title.replace('\\', '\\\\').replace('"', '\\"')
            artist = self.artist.replace('\\', '\\\\').replace('"', '\\"')
            query = f'recording:"{title}" AND artist:"{artist}"'
            url = 'https://musicbrainz.org/ws/2/recording/?' + urllib.parse.urlencode({
                'query': query,
                'fmt': 'json',
                'limit': 8,
            })
            request = urllib.request.Request(
                url,
                headers={
                    'User-Agent': 'UNDERGROUND Desktop Player/1.0 (metadata lookup)',
                    'Accept': 'application/json',
                },
            )
            OnlineMetadataLookupWorker._last_request_time = time.monotonic()
            with urllib.request.urlopen(request, timeout=20) as response:
                payload = json.loads(response.read(2 * 1024 * 1024).decode('utf-8'))
            if not isinstance(payload, dict) or not isinstance(payload.get('recordings', []), list):
                raise ValueError('MusicBrainz returned an invalid response.')
            candidates = []
            for result in payload.get('recordings', []):
                if not isinstance(result, dict):
                    continue
                title = str(result.get('title', '')).strip()
                credits = result.get('artist-credit', [])
                if not isinstance(credits, list):
                    credits = []
                artist_names = []
                for item in credits:
                    if not isinstance(item, dict):
                        continue
                    artist = item.get('artist')
                    artist_name = item.get('name')
                    if not artist_name and isinstance(artist, dict):
                        artist_name = artist.get('name')
                    if artist_name:
                        artist_names.append(str(artist_name).strip())
                artist_name = ', '.join(name for name in artist_names if name)
                releases = result.get('releases', [])
                if not isinstance(releases, list):
                    releases = []
                release = releases[0] if releases and isinstance(releases[0], dict) else {}
                release_id = str(release.get('id', ''))
                candidates.append({
                    'title': title,
                    'artist': artist_name,
                    'album': str(release.get('title', '')).strip(),
                    'year': str(release.get('date', '')).strip()[:4],
                    'release_id': release_id,
                    'cover_url': (
                        f'https://coverartarchive.org/release/{release_id}/front-500'
                        if release_id else ''
                    ),
                })
            self.completed.emit(candidates, '')
        except (OSError, ValueError, urllib.error.URLError, json.JSONDecodeError) as exc:
            self.completed.emit([], str(exc))


class CoverArtDownloadWorker(QThread):
    completed = Signal(str, str)

    def __init__(self, url, destination, parent=None):
        super().__init__(parent)
        self.url = url
        self.destination = destination

    def run(self):
        try:
            request = urllib.request.Request(
                self.url,
                headers={'User-Agent': 'UNDERGROUND Desktop Player/1.0 (cover art lookup)'},
            )
            with urllib.request.urlopen(request, timeout=20) as response:
                if urlsplit(response.geturl()).scheme != 'https':
                    raise ValueError('Cover art downloads must remain on HTTPS.')
                data = response.read(MAX_COVER_DOWNLOAD_BYTES + 1)
            if not data:
                raise ValueError('The cover art service returned an empty image.')
            if len(data) > MAX_COVER_DOWNLOAD_BYTES:
                raise ValueError('Cover art is larger than the 15 MB limit.')
            image = QImage.fromData(data)
            if image.isNull():
                raise ValueError('The cover art service did not return a valid image.')
            self.destination.parent.mkdir(parents=True, exist_ok=True)
            if not image.save(str(self.destination), 'PNG'):
                raise OSError(f'Could not save cover art to {self.destination}.')
            self.completed.emit(str(self.destination), '')
        except (OSError, ValueError, urllib.error.URLError) as exc:
            self.completed.emit('', str(exc))


class StableComboBox(QComboBox):
    def wheelEvent(self, event):
        event.ignore()


class BackgroundWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.image = QImage()
        self.movie = None
        self.overlay_opacity = 0.58
        self.base_color = QColor(THEMES['After Hours'][0])

    def set_base_color(self, color):
        self.base_color = QColor(color)
        self.update()

    def set_overlay_opacity(self, opacity):
        self.overlay_opacity = opacity / 100
        self.update()

    def set_background(self, path, opacity):
        image = QImage()
        movie = None
        if path:
            if Path(path).suffix.casefold() == '.gif':
                movie = QMovie(path)
                if not movie.isValid():
                    movie.deleteLater()
                    raise ValueError('This GIF could not be opened.')
                movie.frameChanged.connect(self.update)
            else:
                image = QImage(path)
                if image.isNull():
                    raise ValueError('This image could not be opened.')
        if self.movie:
            self.movie.stop()
            self.movie.deleteLater()
        self.movie = movie
        self.image = image
        self.set_overlay_opacity(opacity)
        if self.movie:
            self.movie.start()
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), self.base_color)
        pixmap = self.movie.currentPixmap() if self.movie else QPixmap.fromImage(self.image)
        if not pixmap.isNull():
            scaled = pixmap.scaled(
                self.size(),
                Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation,
            )
            x = (self.width() - scaled.width()) // 2
            y = (self.height() - scaled.height()) // 2
            painter.drawPixmap(x, y, scaled)
            painter.fillRect(self.rect(), QColor(10, 8, 7, int(self.overlay_opacity * 255)))


@dataclass
class Track:
    title: str
    path: str = ''
    artist: str = 'Unknown artist'
    duration: float = 0.0
    source: str = 'Local'
    art_path: str = ''
    album: str = ''
    year: str = ''

    @property
    def key(self):
        return str(Path(self.path).resolve()).casefold() if self.path else self.title.casefold()


def duration_of(path):
    try:
        audio = MutagenFile(str(path), easy=True)
        if audio and audio.info:
            return float(audio.info.length)
    except (OSError, ValueError):
        pass
    if path.suffix.casefold() == '.wav':
        try:
            with wave.open(str(path), 'rb') as audio:
                return audio.getnframes() / audio.getframerate()
        except (OSError, wave.Error, ZeroDivisionError):
            return 0.0
    try:
        return float(pygame.mixer.Sound(str(path)).get_length())
    except pygame.error:
        return 0.0


def _first_tag(tags, *names):
    if not tags:
        return ''
    id3_frames = {
        'title': 'TIT2',
        'artist': 'TPE1',
        'albumartist': 'TPE2',
        'album': 'TALB',
        'date': 'TDRC',
        'year': 'TDRC',
    }
    for name in names:
        value = tags.get(id3_frames.get(name, name) if isinstance(tags, ID3) else name)
        if value is not None and isinstance(tags, ID3):
            text = getattr(value, 'text', None)
            if text:
                return str(text[0]).strip()
        if isinstance(value, (list, tuple)) and value:
            return str(value[0]).strip()
        if value:
            return str(value).strip()
    return ''


def metadata_for_file(path):
    title = path.stem.replace('_', ' ').title()
    artist = 'Local file'
    album = ''
    year = ''
    art_path = ''
    try:
        audio = MutagenFile(str(path), easy=True)
        if audio:
            title = _first_tag(audio, 'title') or title
            artist = _first_tag(audio, 'artist', 'albumartist') or artist
            album = _first_tag(audio, 'album')
            year = _first_tag(audio, 'date', 'year')[:4]
    except (OSError, ValueError):
        pass

    try:
        raw_audio = MutagenFile(str(path))
        picture_data = []
        if raw_audio:
            if isinstance(raw_audio.tags, ID3):
                title = _first_tag(raw_audio.tags, 'title') or title
                artist = _first_tag(raw_audio.tags, 'artist', 'albumartist') or artist
                album = _first_tag(raw_audio.tags, 'album') or album
                year = _first_tag(raw_audio.tags, 'date', 'year')[:4] or year
            for picture in getattr(raw_audio, 'pictures', []):
                if getattr(picture, 'data', None):
                    picture_data.append(picture.data)
            for key, value in (raw_audio.tags or {}).items():
                if str(key).casefold() == 'metadata_block_picture':
                    parts = value if isinstance(value, (list, tuple)) else (value,)
                    for part in parts:
                        if isinstance(part, str):
                            encoded = part.split('=', 1)[-1] if part.startswith('metadata_block_picture') else part
                            picture_data.append(Picture(base64.b64decode(encoded)).data)
                    continue
                data = getattr(value, 'data', None)
                if isinstance(data, bytes):
                    picture_data.append(data)
                elif isinstance(value, (bytes, bytearray)):
                    picture_data.append(bytes(value))
                elif isinstance(value, str) and value.startswith('metadata_block_picture'):
                    encoded = value.split('=', 1)[-1]
                    picture_data.append(Picture(base64.b64decode(encoded)).data)
                elif isinstance(value, (list, tuple)):
                    for part in value:
                        if isinstance(part, (bytes, bytearray)):
                            picture_data.append(bytes(part))
                        elif getattr(part, 'data', None):
                            picture_data.append(part.data)
                        elif isinstance(part, str) and part.startswith('metadata_block_picture'):
                            encoded = part.split('=', 1)[-1]
                            picture_data.append(Picture(base64.b64decode(encoded)).data)

        for data in picture_data:
            image = QImage.fromData(data)
            if image.isNull():
                continue
            artwork_dir = APP_DIR / 'artwork'
            artwork_dir.mkdir(parents=True, exist_ok=True)
            digest = hashlib.sha256(str(path.resolve()).casefold().encode('utf-8')).hexdigest()
            destination = artwork_dir / f'{digest}.png'
            if image.save(str(destination), 'PNG'):
                art_path = str(destination)
                break
    except (OSError, ValueError, TypeError):
        pass
    return title, artist, album, year, duration_of(path), art_path


def write_track_metadata(path, title, artist, album, year):
    audio = MutagenFile(str(path), easy=True)
    if audio is None:
        raise ValueError(f'Could not read audio metadata from {path}.')
    if audio.tags is None:
        audio.add_tags()
    values = {
        'title': title,
        'artist': artist,
        'album': album,
        'date': year,
    }
    if isinstance(audio.tags, ID3):
        id3_frames = {
            'title': ('TIT2', TIT2),
            'artist': ('TPE1', TPE1),
            'album': ('TALB', TALB),
            'date': ('TDRC', TDRC),
        }
        for key, value in values.items():
            frame_name, frame_type = id3_frames[key]
            audio.tags.delall(frame_name)
            if value:
                audio.tags.add(frame_type(encoding=3, text=value))
        audio.save()
        return
    for key, value in values.items():
        if value:
            audio.tags[key] = [value]
        elif key in audio.tags:
            del audio.tags[key]
    audio.save()


def embed_cover_art(audio_path, image_path):
    raw_audio = MutagenFile(str(audio_path))
    if raw_audio is None:
        raise ValueError(f'Could not read audio file: {audio_path}')
    image = QImage(str(image_path))
    if image.isNull():
        raise ValueError(f'Could not read cover image: {image_path}')
    image_format = mimetypes.guess_type(str(image_path))[0] or 'image/png'
    if image_format not in ('image/jpeg', 'image/png'):
        image_format = 'image/png'
    image_data = Path(image_path).read_bytes()

    if Path(audio_path).suffix.casefold() == '.ogg':
        picture = Picture()
        picture.type = 3
        picture.mime = image_format
        picture.desc = 'Cover'
        picture.data = image_data
        if raw_audio.tags is None:
            raw_audio.add_tags()
        raw_audio.tags['metadata_block_picture'] = [
            base64.b64encode(picture.write()).decode('ascii')
        ]
    else:
        if raw_audio.tags is None:
            raw_audio.add_tags()
        raw_audio.tags.delall('APIC')
        raw_audio.tags.add(APIC(
            encoding=3,
            mime=image_format,
            type=3,
            desc='Cover',
            data=image_data,
        ))
    raw_audio.save()


def generated_cover_for_file(path):
    title = path.stem.replace('_', ' ').replace('-', ' ').strip() or 'UNTITLED TRACK'
    digest = hashlib.sha256(path.stem.casefold().encode('utf-8')).digest()
    palettes = (
        ('#15151d', '#514176', '#d2b8ff'),
        ('#1c1412', '#8a3d32', '#ffc2a4'),
        ('#101b1a', '#276b61', '#a8e8d1'),
        ('#171a22', '#365a8a', '#b6d8ff'),
        ('#201811', '#86602e', '#f4d18c'),
        ('#1c1420', '#85466f', '#ffc0dc'),
    )
    background, secondary, highlight = palettes[digest[0] % len(palettes)]
    artwork_dir = APP_DIR / 'artwork'
    artwork_dir.mkdir(parents=True, exist_ok=True)
    destination = artwork_dir / f'{hashlib.sha256(title.casefold().encode("utf-8")).hexdigest()}.png'
    if destination.is_file():
        return destination

    image = QImage(512, 512, QImage.Format.Format_ARGB32_Premultiplied)
    painter = QPainter(image)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    gradient = QLinearGradient(0, 0, 512, 512)
    gradient.setColorAt(0, QColor(background))
    gradient.setColorAt(1, QColor(secondary))
    painter.fillRect(QRect(0, 0, 512, 512), gradient)
    painter.setPen(QColor(highlight))
    painter.setOpacity(0.35)
    painter.drawEllipse(302, -92, 300, 300)
    painter.drawEllipse(354, -40, 196, 196)
    painter.drawLine(32, 270, 480, 150)
    painter.setOpacity(1)
    painter.setPen(QColor(highlight))
    painter.setFont(QFont('Segoe UI', 10, QFont.Weight.Bold))
    painter.drawText(36, 54, 'UNDERGROUND  /  LOCAL FILE')
    painter.setPen(QColor('#ffffff'))
    title_font = QFont('Segoe UI', 29, QFont.Weight.Bold)
    painter.setFont(title_font)
    metrics = QFontMetrics(title_font)
    lines = []
    for word in title.upper().split():
        candidate = f'{lines[-1]} {word}'.strip() if lines else word
        if lines and metrics.horizontalAdvance(candidate) > 440 and len(lines) < 3:
            lines.append(word)
        elif lines:
            lines[-1] = metrics.elidedText(candidate, Qt.TextElideMode.ElideRight, 440)
        else:
            lines.append(candidate)
    for index, line in enumerate(lines[:3]):
        painter.drawText(36, 350 + index * 39, line)
    painter.setPen(QColor(highlight))
    painter.setFont(QFont('Segoe UI', 9, QFont.Weight.DemiBold))
    painter.drawText(36, 472, 'FILE-BASED ARTWORK  ·  PERSONAL MUSIC LIBRARY')
    painter.end()
    if not image.save(str(destination), 'PNG'):
        raise OSError(f'Could not write generated cover art: {destination}')
    return destination


def fmt_time(seconds):
    minutes, seconds = divmod(max(0, int(seconds)), 60)
    return f'{minutes:02d}:{seconds:02d}'


class UndergroundWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('UNDERGROUND — Local Music Player')
        self.setWindowIcon(QIcon(str(APP_LOGO_PATH)))
        self.resize(1240, 780)
        self.setMinimumSize(920, 580)
        self.state = self._load_state()
        saved_theme = self.state.get('theme', 'After Hours')
        if not isinstance(saved_theme, str):
            saved_theme = 'After Hours'
        legacy_themes = {'Midnight': 'After Hours', 'Charcoal': 'Obsidian', 'Blood Red': 'After Hours'}
        saved_theme = legacy_themes.get(saved_theme, saved_theme)
        self.theme_name = saved_theme if saved_theme in THEMES else 'After Hours'
        saved_custom_theme = self.state.get('custom_theme_colors', {})
        custom_defaults = THEMES[self.theme_name]
        custom_keys = ('background', 'surface', 'card', 'text', 'muted')
        self.custom_theme_palette = tuple(
            (parse_color(saved_custom_theme.get(key, '')).name() if isinstance(saved_custom_theme, dict) and parse_color(saved_custom_theme.get(key, '')) else custom_defaults[index])
            for index, key in enumerate(custom_keys)
        )
        self.custom_theme_active = self.state.get('custom_theme_active') is True or self.state.get('theme') == 'Custom'
        if self.custom_theme_active:
            self.theme_name = 'Custom'
        saved_accent = self.state.get('accent', 'Violet')
        self.accent_name = saved_accent if isinstance(saved_accent, str) and (saved_accent in ACCENTS or saved_accent == 'Custom Gradient') else 'Violet'
        saved_gradient = self.state.get('accent_gradient', {})
        default_accent = ACCENTS.get(self.accent_name, ACCENTS['Violet'])
        start = saved_gradient.get('start', default_accent) if isinstance(saved_gradient, dict) else default_accent
        end = saved_gradient.get('end', default_accent) if isinstance(saved_gradient, dict) else default_accent
        self.accent_gradient_start = parse_color(start).name() if parse_color(start) else default_accent
        self.accent_gradient_end = parse_color(end).name() if parse_color(end) else default_accent
        self.accent = self.accent_gradient_start
        self.accent_fill = f'qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {self.accent_gradient_start}, stop:1 {self.accent_gradient_end})'
        saved_appearance = self.state.get('appearance_style', 'Classic')
        self.appearance_style = saved_appearance if saved_appearance in APPEARANCE_STYLES else 'Classic'
        self.palette = self.custom_theme_palette if self.custom_theme_active else THEMES[self.theme_name]
        self.bg, self.surface, self.card, self.text_color, self.muted = self.palette
        saved_background = self.state.get('background_path', '')
        self.background_path = saved_background if isinstance(saved_background, str) else ''
        if self.background_path and not Path(self.background_path).is_file():
            self.background_path = ''
        saved_opacity = self.state.get('background_opacity', 58)
        if isinstance(saved_opacity, (int, float)) and not isinstance(saved_opacity, bool):
            self.background_opacity = max(0, min(90, int(saved_opacity)))
        else:
            self.background_opacity = 58
        saved_cursor = self.state.get('cursor_path', '')
        self.cursor_path = saved_cursor if isinstance(saved_cursor, str) else ''
        if self.cursor_path and not Path(self.cursor_path).is_file():
            self.cursor_path = ''
        self._cursor_overridden = False
        self.hud_off = self.state.get('hud_off') is True
        available_fonts = {family.casefold(): family for family in QFontDatabase.families()}
        requested_font = self.state.get('font_family', QApplication.font().family())
        self.font_family = (
            available_fonts.get(requested_font.casefold(), QApplication.font().family())
            if isinstance(requested_font, str)
            else QApplication.font().family()
        )
        self.custom_stylesheet = self.state.get('custom_stylesheet', '')
        if not isinstance(self.custom_stylesheet, str):
            self.custom_stylesheet = ''
        self.custom_stylesheet_error = validate_stylesheet(self.custom_stylesheet)
        if self.custom_stylesheet_error:
            self.custom_stylesheet = ''
        self.compact_mode = self.state.get('compact_mode') is True
        self.fullscreen_mode = self.state.get('fullscreen_mode') is True
        self._windowed_geometry = None
        self.plugin_stylesheet = ''
        self.plugin_status = ''
        self._reload_css_plugins()
        if self.custom_stylesheet_error:
            self.plugin_status += f'\nSaved custom CSS was ignored: {self.custom_stylesheet_error}'
        application_font = QApplication.font()
        application_font.setFamily(self.font_family)
        QApplication.setFont(application_font)
        self.library = []
        self.playlists = self.state.get('playlists', {})
        self.favorites = set(self.state.get('favorites', []))
        self.history = self.state.get('history', [])
        saved_artwork = self.state.get('artwork_overrides', {})
        self.artwork_overrides = (
            {key: value for key, value in saved_artwork.items() if isinstance(key, str) and isinstance(value, str)}
            if isinstance(saved_artwork, dict) else {}
        )
        self.queue = []
        self.current_index = -1
        self.current_track = None
        self.playing = False
        self.paused = False
        self.shuffle = False
        self.repeat = False
        self.position_offset = 0.0
        self.scrubbing = False
        self.status_text = 'READY WHEN YOU ARE'
        self._load_saved_library()
        try:
            pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
            pygame.mixer.music.set_volume(float(self.state.get('volume', .75)))
            self.volume = float(self.state.get('volume', .75))
            self.audio_error = ''
        except pygame.error as exc:
            self.volume = .75
            self.audio_error = str(exc)

        self._build_ui()
        self._apply_styles()
        self._show_page('Home')
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(250)
        self._shortcuts()
        if self.audio_error:
            self._set_status(f'AUDIO DEVICE UNAVAILABLE · {self.audio_error}')

    def _load_state(self):
        try:
            if STATE_PATH.exists():
                data = json.loads(STATE_PATH.read_text(encoding='utf-8'))
                return data if isinstance(data, dict) else {}
        except (OSError, json.JSONDecodeError):
            return {}
        return {}

    def _load_saved_library(self):
        known = set()
        for value in self.state.get('local_files', []):
            path = Path(value)
            if path.is_file() and path.suffix.lower() in SUPPORTED_AUDIO and str(path.resolve()).casefold() not in known:
                track = self._track_for_file(path)
                override = self.artwork_overrides.get(track.key)
                if override and Path(override).is_file():
                    track.art_path = override
                self.library.append(track)
                known.add(track.key)

    def _save_state(self):
        APP_DIR.mkdir(parents=True, exist_ok=True)
        data = {
            'theme': self.theme_name,
            'custom_theme_active': self.custom_theme_active,
            'custom_theme_colors': dict(zip(('background', 'surface', 'card', 'text', 'muted'), self.custom_theme_palette)),
            'accent': self.accent_name,
            'accent_gradient': {'start': self.accent_gradient_start, 'end': self.accent_gradient_end},
            'appearance_style': self.appearance_style,
            'volume': self.volume,
            'background_path': self.background_path,
            'background_opacity': self.background_opacity,
            'cursor_path': self.cursor_path,
            'hud_off': self.hud_off,
            'font_family': self.font_family,
            'custom_stylesheet': self.custom_stylesheet,
            'compact_mode': self.compact_mode,
            'fullscreen_mode': self.fullscreen_mode,
            'local_files': [track.path for track in self.library if track.path and track.source == 'Local'],
            'favorites': sorted(self.favorites),
            'history': self.history[:60],
            'playlists': self.playlists,
            'artwork_overrides': self.artwork_overrides,
        }
        temporary = STATE_PATH.with_suffix('.tmp')
        temporary.write_text(json.dumps(data, indent=2), encoding='utf-8')
        temporary.replace(STATE_PATH)

    def _build_ui(self):
        root = BackgroundWidget()
        try:
            root.set_background(self.background_path, self.background_opacity)
        except ValueError as exc:
            self.background_path = ''
            root.set_background('', self.background_opacity)
            QMessageBox.warning(self, 'Saved background unavailable', f'{exc}\nThe saved background has been cleared.')
        self.root_widget = root
        self.setCentralWidget(root)
        shell = QHBoxLayout(root)
        shell.setContentsMargins(0, 0, 0, 0)
        shell.setSpacing(0)
        self.sidebar = QFrame()
        self.sidebar.setObjectName('sidebar')
        self.sidebar.setFixedWidth(172)
        nav = QVBoxLayout(self.sidebar)
        nav.setContentsMargins(15, 20, 12, 16)
        nav.setSpacing(4)

        wordmark = QLabel('UNDERGROUND')
        wordmark.setObjectName('wordmark')
        nav.addWidget(wordmark)
        tagline = QLabel('LOCAL MUSIC PLAYER')
        tagline.setObjectName('tagline')
        tagline.setWordWrap(True)
        nav.addWidget(tagline)
        nav.addSpacing(8)
        self.nav_buttons = {}
        home_button = QPushButton('HOME')
        home_button.setObjectName('navButton')
        home_button.setCursor(Qt.CursorShape.PointingHandCursor)
        home_button.clicked.connect(lambda: self._show_page('Home'))
        nav.addWidget(home_button)
        self.nav_buttons['Home'] = home_button
        for label in ('Liked Songs', 'Playlists'):
            button = QPushButton(label.upper())
            button.setObjectName('navButton')
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(lambda _checked=False, page=label: self._show_page(page))
            nav.addWidget(button)
            self.nav_buttons[label] = button
        spotify_button = QPushButton('SPOTIFY')
        spotify_button.setObjectName('navButton')
        spotify_button.setCursor(Qt.CursorShape.PointingHandCursor)
        spotify_button.clicked.connect(lambda: self._show_page('Spotify'))
        nav.addWidget(spotify_button)
        self.nav_buttons['Spotify'] = spotify_button
        divider = QFrame()
        divider.setFrameShape(QFrame.Shape.HLine)
        divider.setObjectName('rule')
        nav.addWidget(divider)
        add_files = QPushButton('+  ADD AUDIO')
        add_files.setObjectName('navButton')
        add_files.clicked.connect(self._import_files)
        nav.addWidget(add_files)
        add_folder = QPushButton('+  IMPORT MUSIC FOLDER')
        add_folder.setObjectName('accentButton')
        add_folder.clicked.connect(self._import_folder)
        nav.addWidget(add_folder)
        nav.addStretch(1)
        self.nav_count = QLabel('')
        self.nav_count.setObjectName('tagline')
        nav.addWidget(self.nav_count)

        shell.addWidget(self.sidebar)
        self.workspace = QWidget()
        self.workspace.setObjectName('workspace')
        work_layout = QVBoxLayout(self.workspace)
        work_layout.setContentsMargins(20, 12, 20, 10)
        work_layout.setSpacing(8)
        self.topbar = QWidget()
        topbar = QHBoxLayout(self.topbar)
        topbar.setContentsMargins(0, 0, 0, 0)
        topbar.setSpacing(6)
        self.back_button = QPushButton('←')
        self.back_button.setObjectName('iconButton')
        self.back_button.clicked.connect(self._back)
        topbar.addWidget(self.back_button)
        self.forward_button = QPushButton('→')
        self.forward_button.setObjectName('iconButton')
        self.forward_button.clicked.connect(self._forward)
        topbar.addWidget(self.forward_button)
        self.search_box = QLineEdit()
        self.search_box.setObjectName('searchBox')
        self.search_box.setPlaceholderText('Filter your library…')
        self.search_box.returnPressed.connect(self._search)
        self.search_box.textChanged.connect(self._search_text_changed)
        self.search_timer = QTimer(self)
        self.search_timer.setSingleShot(True)
        self.search_timer.setInterval(250)
        self.search_timer.timeout.connect(self._search)
        topbar.addWidget(self.search_box, 1)
        library_button = QPushButton('LIBRARY')
        library_button.setObjectName('navButton')
        library_button.clicked.connect(lambda: self._show_page('Your Library'))
        topbar.addWidget(library_button)
        self.settings_button = QPushButton('SETTINGS')
        self.settings_button.setObjectName('navButton')
        self.settings_button.clicked.connect(lambda: self._show_page('Settings'))
        topbar.addWidget(self.settings_button)
        work_layout.addWidget(self.topbar)
        self.pages = QStackedWidget()
        work_layout.addWidget(self.pages, 1)
        self.workspace_layout = work_layout
        self.page_widgets = {}
        self.page_stack = []
        self.forward_stack = []
        self._page_effects = {}
        self._page_animations = {}

        self.playerbar = QFrame()
        self.playerbar.setObjectName('playerbar')
        player_layout = QHBoxLayout(self.playerbar)
        self.player_layout = player_layout
        player_layout.setContentsMargins(12, 8, 12, 8)
        player_layout.setSpacing(8)
        self.cover_thumb = QLabel('U')
        self.cover_thumb.setObjectName('coverThumb')
        self.cover_thumb.setFixedSize(42, 42)
        self.cover_thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
        player_layout.addWidget(self.cover_thumb)
        songinfo = QVBoxLayout()
        songinfo.setSpacing(3)
        self.track_label = QLabel('NOTHING PLAYING')
        self.track_label.setObjectName('trackLabel')
        songinfo.addWidget(self.track_label)
        self.artist_label = QLabel('Import a music folder to get started')
        self.artist_label.setObjectName('artistLabel')
        songinfo.addWidget(self.artist_label)
        player_layout.addLayout(songinfo, 1)
        self.shuffle_button = self._player_button('⇄', self._toggle_shuffle)
        player_layout.addWidget(self.shuffle_button)
        player_layout.addWidget(self._player_button('|◀', self._previous))
        self.play_button = self._player_button('▶', self._toggle_play)
        self.play_button.setObjectName('playButton')
        player_layout.addWidget(self.play_button)
        player_layout.addWidget(self._player_button('▶|', self._next))
        self.repeat_button = self._player_button('↻', self._toggle_repeat)
        player_layout.addWidget(self.repeat_button)
        self.elapsed_label = QLabel('00:00')
        self.elapsed_label.setObjectName('timeLabel')
        self.elapsed_label.setFixedWidth(36)
        player_layout.addWidget(self.elapsed_label)
        self.seek_slider = QSlider(Qt.Orientation.Horizontal)
        self.seek_slider.setObjectName('seekSlider')
        self.seek_slider.setRange(0, 1000)
        self.seek_slider.sliderPressed.connect(lambda: setattr(self, 'scrubbing', True))
        self.seek_slider.sliderReleased.connect(self._seek)
        self.seek_slider.setMinimumWidth(64)
        self.seek_slider.setMaximumWidth(160)
        player_layout.addWidget(self.seek_slider, 1)
        self.total_label = QLabel('--:--')
        self.total_label.setObjectName('timeLabel')
        self.total_label.setFixedWidth(36)
        player_layout.addWidget(self.total_label)
        self.queue_button = self._player_button('QUEUE', self._show_queue)
        player_layout.addWidget(self.queue_button)
        self.volume_slider = QSlider(Qt.Orientation.Horizontal)
        self.volume_slider.setObjectName('volumeSlider')
        self.volume_slider.setRange(0, 100)
        self.volume_slider.setValue(int(self.volume * 100))
        self.volume_slider.valueChanged.connect(self._set_volume)
        self.volume_slider.setFixedWidth(52)
        player_layout.addWidget(self.volume_slider)
        work_layout.addWidget(self.playerbar)
        shell.addWidget(self.workspace, 1)
        if not self._apply_custom_cursor():
            self.cursor_path = ''
        self._apply_hud_visibility()
        self._apply_compact_layout()

    def _player_button(self, text, callback):
        button = QPushButton(text)
        button.setObjectName('playerButton')
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.clicked.connect(callback)
        return button

    def _apply_styles(self):
        liquid_glass = self.appearance_style == 'Liquid Glass'
        sidebar_background = 'rgba(20, 17, 18, 176)' if liquid_glass else 'rgba(15, 12, 11, 232)'
        input_background = 'rgba(255, 255, 255, 18)' if liquid_glass else 'rgba(18, 15, 14, 220)'
        player_background = (
            'qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 rgba(255,255,255,38), stop:0.12 rgba(255,255,255,22), stop:1 rgba(255,255,255,12))'
            if liquid_glass else 'rgba(16, 13, 12, 242)'
        )
        player_border = '1px solid rgba(255,255,255,76)' if liquid_glass else '1px solid rgba(255,255,255,28)'
        base_stylesheet = f"""
            QMainWindow {{ background: {self.bg}; color: {self.text_color}; }}
            QWidget#workspace {{ background: transparent; color: {self.text_color}; }}
            QFrame#sidebar {{ background: {sidebar_background}; border-right: 1px solid rgba(255,255,255,32); }}
            QLabel#wordmark {{ color: #f4f0e9; font-size: 20px; font-weight: 900; letter-spacing: 1px; }}
            QLabel#tagline {{ color: #b8a99d; font-size: 8px; font-weight: 700; letter-spacing: 1px; margin-top: 5px; }}
            QPushButton#navButton {{ background: transparent; color: #a9a39c; border: 0; border-radius: 6px; text-align: left; padding: 8px 8px; font-size: 9px; font-weight: 700; letter-spacing: 1px; }}
            QPushButton#navButton:hover {{ background: rgba(255,255,255,12); color: #f4f0e9; }}
            QPushButton#navButton[selected="true"] {{ color: {self.accent}; background: rgba(255,255,255,12); border-left: 2px solid {self.accent}; }}
            QPushButton#accentButton {{ background: {self.accent_fill}; color: #15110e; border: 0; border-radius: 6px; text-align: left; padding: 8px 9px; font-size: 9px; font-weight: 800; margin-top: 8px; }}
            QPushButton#accentButton:hover, QPushButton#playButton:hover {{ background: {self.accent_fill}; }}
            QFrame#rule {{ color: #252321; max-height: 1px; }}
            QLineEdit#searchBox {{ background: {input_background}; color: {self.text_color}; border: 1px solid rgba(255,255,255,35); border-radius: 8px; padding: 7px 11px; font-size: 12px; }}
            QLineEdit#searchBox:focus {{ border: 1px solid {self.accent}; }}
            QComboBox, QTextEdit, QDialog {{ background: {self.surface}; color: {self.text_color}; border: 1px solid rgba(255,255,255,30); border-radius: 6px; padding: 8px; }}
            QComboBox QAbstractItemView {{ background: {self.surface}; color: {self.text_color}; selection-background-color: {self.accent}; }}
            QCheckBox {{ color: {self.text_color}; spacing: 8px; }}
            QCheckBox::indicator {{ width: 16px; height: 16px; border: 1px solid #6c6258; border-radius: 4px; background: #171411; }}
            QCheckBox::indicator:checked {{ background: {self.accent}; border-color: {self.accent}; }}
            QPushButton#secondaryButton {{ background: rgba(255,255,255,8); color: {self.text_color}; border: 1px solid rgba(255,255,255,30); border-radius: 7px; padding: 8px 11px; font-size: 9px; font-weight: 800; letter-spacing: 1px; }}
            QPushButton#secondaryButton:hover {{ border-color: {self.accent}; color: {self.accent}; }}
            QToolButton#playlistMoreButton {{ background: transparent; color: #b9b2a9; border: 0; border-radius: 5px; padding: 4px 9px; font-size: 15px; }}
            QToolButton#playlistMoreButton:hover {{ background: rgba(255,255,255,12); color: {self.text_color}; }}
            QMenu {{ background: {self.surface}; color: {self.text_color}; border: 1px solid rgba(255,255,255,40); padding: 4px; }}
            QMenu::item {{ padding: 7px 22px 7px 10px; border-radius: 4px; }}
            QMenu::item:selected {{ background: rgba(255,255,255,14); color: {self.accent}; }}
            QPushButton#iconButton {{ background: {input_background}; color: #d0c4b8; border: 1px solid rgba(255,255,255,35); border-radius: 8px; min-width: 34px; min-height: 34px; font-size: 18px; }}
            QPushButton#iconButton:hover, QPushButton#playerButton:hover {{ color: {self.accent}; background: rgba(255,255,255,10); }}
            QFrame#playerbar {{ background: {player_background}; border: {player_border}; border-radius: 12px; }}
            QLabel#coverThumb {{ background: #211e1a; color: {self.accent}; font-size: 26px; font-weight: 900; border-radius: 5px; }}
            QLabel#trackLabel {{ color: #f5f1ea; font-size: 12px; font-weight: 700; }}
            QLabel#artistLabel, QLabel#timeLabel {{ color: #89837b; font-size: 10px; }}
            QPushButton#playerButton {{ background: transparent; color: #b9b2a9; border: 0; padding: 6px; font-size: 10px; font-weight: 700; }}
            QPushButton#playButton {{ background: {self.accent_fill}; color: #14110e; border: 0; border-radius: 18px; min-width: 36px; min-height: 36px; font-size: 14px; font-weight: 800; }}
            QSlider::groove:horizontal {{ background: #36332f; height: 3px; border-radius: 2px; }}
            QSlider::sub-page:horizontal {{ background: {self.accent_fill}; border-radius: 2px; }}
            QSlider::handle:horizontal {{ background: {self.accent_gradient_end}; width: 10px; margin: -4px 0; border-radius: 5px; }}
            QScrollArea, QScrollArea QWidget {{ border: 0; background: transparent; }}
            QScrollBar:vertical {{ width: 8px; background: transparent; }}
            QScrollBar::handle:vertical {{ background: #38342f; border-radius: 4px; min-height: 24px; }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
        """
        self.setStyleSheet(
            '\n'.join(part for part in (base_stylesheet, self.plugin_stylesheet, self.custom_stylesheet) if part.strip())
        )
        for page, button in self.nav_buttons.items():
            button.setProperty('selected', False)
        if hasattr(self, 'root_widget'):
            self.root_widget.set_base_color(self.bg)

    def _shortcuts(self):
        QShortcut(QKeySequence('Space'), self, activated=self._toggle_play)
        QShortcut(QKeySequence('Ctrl+F'), self, activated=self._focus_library_filter)
        QShortcut(QKeySequence('Ctrl+L'), self, activated=self._show_lyrics)
        QShortcut(QKeySequence('Ctrl+O'), self, activated=self._import_files)
        QShortcut(QKeySequence('Ctrl+Shift+O'), self, activated=self._import_folder)
        QShortcut(QKeySequence('Ctrl+Right'), self, activated=self._next)
        QShortcut(QKeySequence('Ctrl+Left'), self, activated=self._previous)
        QShortcut(QKeySequence('F10'), self, activated=self._toggle_hud)
        QShortcut(QKeySequence('F11'), self, activated=self._toggle_fullscreen)
        QShortcut(QKeySequence('Ctrl+Shift+S'), self, activated=lambda: self._show_page('Spotify'))

    def _page(self, key):
        if key in self.page_widgets:
            return self.page_widgets[key]
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(2, 4, 12, 18)
        layout.setSpacing(10)
        scroll.setWidget(content)
        scroll._content_widget = content
        scroll._layout = layout
        self.page_widgets[key] = scroll
        self.pages.addWidget(scroll)
        return scroll

    def _clear_page(self, page):
        layout = page._layout
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

    def _header(self, layout, eyebrow, title, subtitle=''):
        kicker = QLabel(eyebrow.upper())
        kicker.setStyleSheet(f'color:{self.accent};font-size:9px;font-weight:800;letter-spacing:1.5px;')
        layout.addWidget(kicker)
        heading = QLabel(title)
        heading.setWordWrap(True)
        heading.setStyleSheet(f'color:{self.text_color};font-size:27px;font-weight:800;letter-spacing:-1px;')
        layout.addWidget(heading)
        if subtitle:
            sub = QLabel(subtitle)
            sub.setWordWrap(True)
            sub.setStyleSheet(f'color:{self.muted};font-size:11px;')
            layout.addWidget(sub)

    def _section(self, layout, title, action=None):
        row = QHBoxLayout()
        label = QLabel(title)
        label.setStyleSheet(f'color:{self.text_color};font-size:19px;font-weight:800;')
        row.addWidget(label)
        row.addStretch(1)
        if action:
            button = QPushButton('VIEW ALL  →')
            button.setObjectName('playerButton')
            button.clicked.connect(action)
            row.addWidget(button)
        layout.addLayout(row)

    def _show_page(self, name, record_history=True):
        playlist_prefix = 'Playlist: '
        if name.startswith(playlist_prefix) and name[len(playlist_prefix):] not in self.playlists:
            name = 'Playlists'
        if record_history:
            self._record_navigation(name)
        if name == 'Settings':
            self._show_settings()
            return
        if name == 'Queue':
            self._show_queue(record_history=False)
            return
        if name == 'Spotify':
            self._show_spotify()
            return
        page = self._page(name)
        self._clear_page(page)
        layout = page._layout
        for key, button in self.nav_buttons.items():
            button.setProperty('selected', key == name)
            button.style().unpolish(button)
            button.style().polish(button)

        if name == 'Home':
            self._build_home(layout)
        elif name == 'Your Library':
            self._build_library(layout, self._filtered_tracks(self.library))
        elif name == 'Liked Songs':
            self._build_library(layout, self._filtered_tracks([track for track in self.library if track.key in self.favorites]), 'Liked Songs')
        elif name == 'Playlists':
            self._build_playlists(layout)
        elif name.startswith('Playlist: '):
            self._build_playlist_tracks(layout, name.removeprefix('Playlist: '))
        self._activate_page(page)
        self.nav_count.setText(f'{len(self.library)} SAVED ITEMS')

    def _record_navigation(self, name):
        if self.page_stack and self.page_stack[-1] == name:
            return
        if self.page_stack:
            self.forward_stack.clear()
        self.page_stack.append(name)

    def _activate_page(self, page):
        self.pages.setCurrentWidget(page)
        effect = self._page_effects.get(page)
        if effect is None:
            effect = QGraphicsOpacityEffect(page)
            page.setGraphicsEffect(effect)
            self._page_effects[page] = effect
        if self.appearance_style == 'Liquid Glass':
            start_opacity = 0.94
            duration = 180
        else:
            start_opacity = 0.78
            duration = 220
        animation = self._page_animations.get(page)
        if animation is None:
            animation = QPropertyAnimation(effect, b'opacity', self)
            self._page_animations[page] = animation
        else:
            animation.stop()
        animation.setDuration(duration)
        animation.setStartValue(start_opacity)
        animation.setEndValue(1.0)
        animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        animation.start()

    def _show_spotify(self):
        for key, button in self.nav_buttons.items():
            button.setProperty('selected', key == 'Spotify')
            button.style().unpolish(button)
            button.style().polish(button)
        page = getattr(self, '_spotify_widget', None)
        if page is None:
            page = QWidget()
            layout = QVBoxLayout(page)
            layout.setContentsMargins(20, 12, 20, 10)
            if SpotifyPanel is None:
                label = QLabel(
                    'Spotify needs PySide6-Addons for QtWebEngine.\n\n'
                    f'{SPOTIFY_IMPORT_ERROR}'
                )
                label.setWordWrap(True)
                layout.addWidget(label)
            else:
                self.spotify_panel = SpotifyPanel(page, app_dir=APP_DIR)
                self.spotify_panel.status_message.connect(self._set_status)
                self.spotify_panel.files_downloaded.connect(
                    self._add_downloaded_files
                )
                layout.addWidget(self.spotify_panel)
            self.pages.addWidget(page)
            self._spotify_widget = page
        self.pages.setCurrentWidget(page)
        self.nav_count.setText(f'{len(self.library)} SAVED ITEMS')

    def _add_downloaded_files(self, paths):
        self._add_files([Path(path) for path in paths])

    def _build_home(self, layout):
        self._header(layout, 'HOME', 'Your music.', f'{len(self.library)} tracks in your library')
        hero = QFrame()
        if self.appearance_style == 'Liquid Glass':
            hero.setStyleSheet('QFrame { background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 rgba(255,255,255,36), stop:0.18 rgba(255,255,255,17), stop:1 rgba(255,255,255,10)); border:1px solid rgba(255,255,255,70); border-radius:12px; }')
        else:
            hero.setStyleSheet('QFrame { background:transparent; border:0; }')
        hero_layout = QHBoxLayout(hero)
        hero_layout.setContentsMargins(18, 14, 18, 14)
        editorial = QVBoxLayout()
        title = QLabel('Your collection, your way.')
        title.setStyleSheet(f'color:{self.text_color};font-size:22px;font-weight:800;')
        editorial.addWidget(title)
        description = QLabel('Local files, ready when you are.')
        description.setWordWrap(True)
        description.setStyleSheet(f'color:{self.muted};font-size:12px;')
        editorial.addWidget(description)
        explore = QPushButton('OPEN LIBRARY')
        explore.setObjectName('accentButton')
        explore.clicked.connect(lambda: self._show_page('Your Library'))
        editorial.addWidget(explore, alignment=Qt.AlignmentFlag.AlignLeft)
        hero_layout.addLayout(editorial, 1)
        hero_art = QLabel()
        hero_art.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hero_art.setMinimumSize(120, 100)
        logo = QPixmap(str(APP_LOGO_PATH))
        if not logo.isNull():
            hero_art.setPixmap(logo.scaled(
                112, 100,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            ))
        else:
            hero_art.setText('U / G')
        art_background = 'rgba(255,255,255,20)' if self.appearance_style == 'Liquid Glass' else 'transparent'
        hero_art.setStyleSheet(f'background:{art_background};color:{self.accent};font-size:38px;font-weight:900;letter-spacing:-3px;border-radius:7px;')
        hero_layout.addWidget(hero_art)
        layout.addWidget(hero)
        recent = [self._track_by_key(key) for key in self.history]
        recent = [track for track in recent if track]
        self._section(layout, 'Recently played')
        self._card_strip(layout, recent or self.library[:6], 'No recent tracks. Import music to get started.')

    def _card_strip(self, layout, tracks, empty_message):
        if not tracks:
            empty = QLabel(empty_message)
            empty.setWordWrap(True)
            empty.setStyleSheet(f'color:{self.muted};background:{self._surface_fill()};padding:16px;border:1px solid rgba(255,255,255,32);border-radius:8px;')
            layout.addWidget(empty)
            return
        strip = QHBoxLayout()
        for track in tracks[:4]:
            card = self._track_card(track)
            strip.addWidget(card, 1)
        strip.addStretch(1)
        layout.addLayout(strip)

    def _track_card(self, track):
        card = QFrame()
        card.setFixedWidth(132)
        card.setStyleSheet(f'QFrame {{background:transparent;border:0;}}')
        box = QVBoxLayout(card)
        box.setContentsMargins(0, 0, 0, 0)
        box.setSpacing(6)
        artwork = QLabel()
        artwork.setFixedSize(122, 122)
        artwork.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cover = self._find_art(track)
        if cover:
            artwork.setPixmap(QPixmap(str(cover)).scaled(122, 122, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation))
        else:
            initials = ''.join(word[:1] for word in track.title.split()[:2]).upper()
            artwork.setText(initials or 'U/G')
            artwork.setStyleSheet(f'background:#211e1a;color:{self.accent};font-size:42px;font-weight:900;border-radius:5px;')
        artwork.setCursor(Qt.CursorShape.PointingHandCursor)
        artwork.mousePressEvent = lambda _event, item=track: self._play(item)
        box.addWidget(artwork)
        play = QPushButton(track.title)
        play.setToolTip(track.title)
        play.setStyleSheet(f'QPushButton {{background:transparent;color:{self.text_color};border:0;text-align:left;font-size:12px;font-weight:700;padding:3px 0;}} QPushButton:hover {{color:{self.accent};}}')
        play.clicked.connect(lambda _checked=False, item=track: self._play(item))
        box.addWidget(play)
        caption = QLabel(track.artist if track.source != 'Local' else (track.album or 'LOCAL FILE'))
        caption.setStyleSheet(f'color:{self.muted};font-size:10px;')
        box.addWidget(caption)
        return card

    def _find_art(self, track):
        if track.art_path and Path(track.art_path).is_file():
            return Path(track.art_path)
        return None

    def _build_library(self, layout, tracks, title='Your Library'):
        term = self.search_box.text().strip()
        subtitle = f'{len(tracks)} tracks' if not term else f'{len(tracks)} matches for “{term}”'
        self._header(layout, 'Your collection', title, subtitle)
        row = QHBoxLayout()
        add = QPushButton('ADD AUDIO FILES')
        add.setObjectName('accentButton')
        add.clicked.connect(self._import_files)
        row.addWidget(add)
        folder = QPushButton('IMPORT MUSIC FOLDER')
        folder.setObjectName('secondaryButton')
        folder.clicked.connect(self._import_folder)
        row.addWidget(folder)
        download = QPushButton('DOWNLOAD AUDIO URL')
        download.setObjectName('secondaryButton')
        download.setToolTip('Download a direct HTTPS audio file you are authorized to save.')
        download.clicked.connect(self._download_audio_url)
        row.addWidget(download)
        row.addStretch(1)
        layout.addLayout(row)
        if not tracks:
            if self.search_box.text().strip():
                empty_message = 'No matching tracks. Clear the filter to see your full library.'
            else:
                empty_message = 'Nothing here yet. Import a folder of audio or add files.'
            empty = QLabel(empty_message)
            empty.setWordWrap(True)
            empty.setMinimumHeight(130)
            empty.setStyleSheet(f'color:{self.muted};background:{self._surface_fill()};padding:18px;border:1px solid rgba(255,255,255,32);border-radius:8px;')
            layout.addWidget(empty)
            return
        table = QVBoxLayout()
        header = QHBoxLayout()
        for label, width in [('TRACK', 4), ('TYPE', 1), ('DURATION', 1), ('', 1)]:
            value = QLabel(label)
            value.setStyleSheet('color:#77716a;font-size:9px;font-weight:800;letter-spacing:1px;padding:8px;')
            header.addWidget(value, width)
        table.addLayout(header)
        for track in tracks:
            track_row = self._track_row(track)
            table.addWidget(track_row)
        layout.addLayout(table)

    def _track_row(self, track, playlist_name=None):
        row = QFrame()
        row.setStyleSheet(f'QFrame {{background:{self._surface_fill()};border:1px solid rgba(255,255,255,32);border-radius:8px;}} QFrame:hover {{border-color:{self.accent};}}')
        line = QHBoxLayout(row)
        line.setContentsMargins(10, 4, 8, 4)
        cover = QLabel()
        cover.setFixedSize(40, 40)
        cover.setAlignment(Qt.AlignmentFlag.AlignCenter)
        art = self._find_art(track)
        if art:
            cover.setPixmap(QPixmap(str(art)).scaled(40, 40, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation))
        line.addWidget(cover)
        names = QVBoxLayout()
        title = QPushButton(track.title)
        title.setToolTip(track.path)
        title.setStyleSheet(f'QPushButton {{background:transparent;border:0;color:{self.text_color};text-align:left;font-size:12px;font-weight:700;}} QPushButton:hover {{color:{self.accent};}}')
        title.clicked.connect(lambda _checked=False, item=track: self._play(item))
        names.addWidget(title)
        details = [value for value in (track.artist, track.album, track.year) if value]
        artist = QLabel('  ·  '.join(details))
        artist.setStyleSheet(f'color:{self.muted};font-size:10px;')
        names.addWidget(artist)
        line.addLayout(names, 4)
        source = QLabel(track.source.upper())
        source.setStyleSheet(f'color:{self.muted};font-size:9px;font-weight:700;')
        line.addWidget(source, 1)
        duration = QLabel(fmt_time(track.duration))
        duration.setStyleSheet(f'color:{self.muted};font-size:10px;')
        line.addWidget(duration, 1)
        like = QPushButton('♥' if track.key in self.favorites else '♡')
        like.setObjectName('playerButton')
        like.setToolTip('Like this track')
        like.clicked.connect(lambda _checked=False, item=track: self._toggle_like(item))
        line.addWidget(like)
        queue = QPushButton('+')
        queue.setObjectName('playerButton')
        queue.setToolTip('Add to queue')
        queue.clicked.connect(lambda: self._enqueue(track))
        line.addWidget(queue)
        more = QToolButton()
        more.setObjectName('playlistMoreButton')
        more.setText('···')
        more.setToolTip('Track actions')
        more.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        menu = QMenu(more)
        edit_metadata = menu.addAction('Edit metadata')
        edit_metadata.triggered.connect(lambda _checked=False, item=track: self._edit_track_metadata(item))
        choose_art = menu.addAction('Choose cover art')
        choose_art.triggered.connect(lambda _checked=False, item=track: self._choose_track_artwork(item))
        lookup = menu.addAction('Look up metadata online')
        lookup.triggered.connect(lambda _checked=False, item=track: self._lookup_online_metadata(item))
        if playlist_name:
            remove_from_playlist = menu.addAction('Remove from this playlist')
            remove_from_playlist.triggered.connect(
                lambda _checked=False, name=playlist_name, item=track:
                self._remove_track_from_playlist(name, item)
            )
        elif self.playlists:
            playlist_menu = menu.addMenu('Add to playlist')
            for name in self.playlists:
                action = playlist_menu.addAction(name)
                action.triggered.connect(
                    lambda _checked=False, playlist_name=name, item=track:
                    self._add_track_to_playlist(playlist_name, item)
                )
        else:
            create_playlist = menu.addAction('Create playlist with this track')
            create_playlist.triggered.connect(
                lambda _checked=False, item=track: self._create_playlist_with_track(item)
            )
        more.setMenu(menu)
        line.addWidget(more)
        return row

    def _filtered_tracks(self, tracks):
        term = self.search_box.text().strip().casefold()
        if not term:
            return tracks
        return [
            track for track in tracks
            if term in track.title.casefold()
            or term in track.artist.casefold()
            or term in track.album.casefold()
            or term in Path(track.path).name.casefold()
        ]

    def _build_playlists(self, layout):
        self._header(layout, 'COLLECTION', 'Playlists', f'{len(self.playlists)} playlists')
        actions = QHBoxLayout()
        create = QPushButton('NEW PLAYLIST  +')
        create.setObjectName('accentButton')
        create.clicked.connect(self._create_playlist)
        actions.addWidget(create)
        import_button = QPushButton('IMPORT')
        import_button.setObjectName('secondaryButton')
        import_button.clicked.connect(self._import_playlist)
        actions.addWidget(import_button)
        actions.addStretch(1)
        layout.addLayout(actions)
        if not self.playlists:
            label = QLabel('No playlists yet.')
            label.setStyleSheet(f'color:{self.muted};padding:20px 2px;border-top:1px solid rgba(255,255,255,28);')
            layout.addWidget(label)
            return
        list_panel = QFrame()
        list_panel.setObjectName('playlistList')
        list_panel_layout = QVBoxLayout(list_panel)
        list_panel_layout.setContentsMargins(0, 4, 0, 4)
        list_panel_layout.setSpacing(0)
        for index, (name, keys) in enumerate(self.playlists.items(), start=1):
            panel = QFrame()
            panel.setObjectName('playlistRow')
            panel.setStyleSheet('QFrame#playlistRow { background: transparent; border-bottom: 1px solid rgba(255,255,255,24); } QFrame#playlistRow:hover { background: rgba(255,255,255,8); }')
            row = QHBoxLayout(panel)
            row.setContentsMargins(10, 7, 8, 7)
            row.setSpacing(12)
            index_label = QLabel(f'{index:02d}')
            index_label.setFixedWidth(24)
            index_label.setStyleSheet(f'color:{self.accent};font-size:10px;font-weight:700;')
            row.addWidget(index_label)
            cover = QLabel()
            cover.setFixedSize(44, 44)
            cover.setAlignment(Qt.AlignmentFlag.AlignCenter)
            playlist_tracks = [self._track_by_key(key) for key in keys]
            first_track = next((track for track in playlist_tracks if track), None)
            art = self._find_art(first_track) if first_track else None
            if art:
                cover.setPixmap(QPixmap(str(art)).scaled(44, 44, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation))
            else:
                cover.setText('—')
                cover.setStyleSheet(f'background:{self._surface_fill()};color:{self.muted};border-radius:4px;font-size:16px;')
            row.addWidget(cover)
            info = QVBoxLayout()
            info.setSpacing(2)
            title = QLabel(name)
            title.setStyleSheet(f'color:{self.text_color};font-size:13px;font-weight:650;')
            info.addWidget(title)
            count = QLabel(f'{len(keys)} tracks')
            count.setStyleSheet(f'color:{self.muted};font-size:10px;')
            info.addWidget(count)
            row.addLayout(info, 1)
            play = QPushButton('PLAY')
            play.setObjectName('playerButton')
            play.setCursor(Qt.CursorShape.PointingHandCursor)
            play.clicked.connect(lambda _checked=False, playlist_name=name: self._play_playlist(playlist_name))
            row.addWidget(play)
            view = QPushButton('VIEW')
            view.setObjectName('playerButton')
            view.clicked.connect(
                lambda _checked=False, playlist_name=name:
                self._show_playlist_contents(playlist_name)
            )
            row.addWidget(view)
            more = QToolButton()
            more.setObjectName('playlistMoreButton')
            more.setText('···')
            more.setToolTip('Playlist actions')
            more.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
            menu = QMenu(more)
            add_current = menu.addAction('Add current track')
            add_current.triggered.connect(lambda _checked=False, playlist_name=name: self._add_to_playlist(playlist_name))
            export = menu.addAction('Export playlist')
            export.triggered.connect(lambda _checked=False, playlist_name=name: self._export_playlist(playlist_name))
            menu.addSeparator()
            delete = menu.addAction('Delete playlist')
            delete.triggered.connect(lambda _checked=False, playlist_name=name: self._delete_playlist(playlist_name))
            more.setMenu(menu)
            row.addWidget(more)
            list_panel_layout.addWidget(panel)
        layout.addWidget(list_panel)

    def _show_playlist_contents(self, name):
        if name not in self.playlists:
            QMessageBox.warning(self, 'Playlist unavailable', f'Could not find the playlist “{name}”.')
            self._show_page('Playlists')
            return
        self._show_page(f'Playlist: {name}')

    def _build_playlist_tracks(self, layout, name):
        if name not in self.playlists:
            return
        tracks = []
        for key in self.playlists[name]:
            track = self._track_by_key(key)
            if track:
                tracks.append(track)
        self._header(layout, 'PLAYLIST', name, f'{len(tracks)} tracks')
        actions = QHBoxLayout()
        play = QPushButton('PLAY PLAYLIST')
        play.setObjectName('accentButton')
        play.clicked.connect(lambda: self._play_playlist(name))
        actions.addWidget(play)
        add = QPushButton('ADD TRACK')
        add.setObjectName('secondaryButton')
        add.clicked.connect(lambda: self._add_library_track_to_playlist(name))
        actions.addWidget(add)
        back = QPushButton('BACK TO PLAYLISTS')
        back.setObjectName('secondaryButton')
        back.clicked.connect(lambda: self._show_page('Playlists'))
        actions.addWidget(back)
        actions.addStretch(1)
        layout.addLayout(actions)
        if not tracks:
            empty = QLabel('This playlist is empty. Add a track from your local library.')
            empty.setStyleSheet(f'color:{self.muted};padding:18px 4px;')
            layout.addWidget(empty)
            return
        for track in tracks:
            layout.addWidget(self._track_row(track, playlist_name=name))

    def _add_library_track_to_playlist(self, name):
        if not self.library:
            QMessageBox.information(self, 'Library is empty', 'Import audio before adding tracks to a playlist.')
            return
        choices = [f'{track.title} — {track.artist}' for track in self.library]
        selection, accepted = QInputDialog.getItem(
            self,
            f'Add track to {name}',
            'Choose a library track:',
            choices,
            0,
            False,
        )
        if accepted:
            self._add_track_to_playlist(name, self.library[choices.index(selection)])

    def _remove_track_from_playlist(self, name, track):
        if name not in self.playlists or track.key not in self.playlists[name]:
            QMessageBox.warning(self, 'Playlist item unavailable', 'That track is no longer in this playlist.')
            return
        self.playlists[name].remove(track.key)
        self._save_state()
        self._show_page(f'Playlist: {name}')

    def _show_settings(self):
        page = self._page('Settings')
        self._clear_page(page)
        layout = page._layout
        for key, button in self.nav_buttons.items():
            button.setProperty('selected', False)
            button.style().unpolish(button)
            button.style().polish(button)
        self._header(layout, 'Settings', 'Preferences', 'Appearance and playback.')
        appearance = self._settings_panel()
        appearance_layout = QVBoxLayout(appearance)
        appearance_layout.setContentsMargins(18, 18, 18, 18)
        appearance_layout.setSpacing(10)
        self._setting_row(appearance_layout, 'VISUAL STYLE', 'Liquid Glass adds translucent surfaces and soft highlights.')
        appearance_style = StableComboBox()
        appearance_style.addItems(APPEARANCE_STYLES)
        appearance_style.setCurrentText(self.appearance_style)
        appearance_style.currentTextChanged.connect(self._change_appearance_style)
        appearance_layout.addWidget(appearance_style)
        self._setting_row(appearance_layout, 'MINIMAL HUD', 'Hide navigation and status popups while keeping the player visible. Press F10 to restore the full interface.')
        self.hud_checkbox = QCheckBox('Hide navigation and status messages')
        self.hud_checkbox.setObjectName('hudOffToggle')
        self.hud_checkbox.setChecked(self.hud_off)
        self.hud_checkbox.toggled.connect(self._set_hud_off)
        appearance_layout.addWidget(self.hud_checkbox)
        self._setting_row(appearance_layout, 'FONT', 'Choose an installed system font for the app.')
        self.font_selector = QFontComboBox()
        self.font_selector.setCurrentFont(QFont(self.font_family))
        self.font_selector.currentFontChanged.connect(self._change_font_family)
        appearance_layout.addWidget(self.font_selector)
        self.compact_checkbox = QCheckBox('Use compact layout')
        self.compact_checkbox.setChecked(self.compact_mode)
        self.compact_checkbox.toggled.connect(self._set_compact_mode)
        appearance_layout.addWidget(self.compact_checkbox)
        self.fullscreen_checkbox = QCheckBox('Use fullscreen mode (F11 toggles)')
        self.fullscreen_checkbox.setChecked(self.fullscreen_mode)
        self.fullscreen_checkbox.toggled.connect(self._set_fullscreen_mode)
        appearance_layout.addWidget(self.fullscreen_checkbox)
        self._setting_row(appearance_layout, 'COLOR THEME', 'Choose a palette for your listening space.')
        theme = StableComboBox()
        theme.addItems([*THEMES.keys(), 'Custom'])
        theme.setCurrentText(self.theme_name)
        theme.currentTextChanged.connect(self._change_theme)
        appearance_layout.addWidget(theme)
        self._setting_row(appearance_layout, 'ACCENT COLOR', 'Set the color used for active controls and highlights.')
        accents = StableComboBox()
        accents.addItems([*ACCENTS.keys(), 'Custom Gradient'])
        accents.setCurrentText(self.accent_name)
        accents.currentTextChanged.connect(self._change_accent)
        appearance_layout.addWidget(accents)
        layout.addWidget(appearance)
        custom_colors = self._settings_panel()
        custom_layout = QVBoxLayout(custom_colors)
        custom_layout.setContentsMargins(16, 14, 16, 14)
        custom_layout.setSpacing(7)
        self._setting_row(custom_layout, 'CUSTOM THEME COLORS', 'Enter HEX, rgb(255, 120, 40), or R, G, B values.')
        self.custom_theme_inputs = {}
        palette_names = ('Background', 'Surface', 'Card', 'Text', 'Muted')
        palette_values = dict(zip(('background', 'surface', 'card', 'text', 'muted'), self.custom_theme_palette))
        for key, label in zip(palette_values, palette_names):
            self.custom_theme_inputs[key] = self._color_input_row(custom_layout, label, palette_values[key])
        apply_theme = QPushButton('APPLY CUSTOM THEME')
        apply_theme.setObjectName('secondaryButton')
        apply_theme.clicked.connect(self._apply_custom_theme)
        custom_layout.addWidget(apply_theme, alignment=Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(custom_colors)

        accent_colors = self._settings_panel()
        accent_layout = QVBoxLayout(accent_colors)
        accent_layout.setContentsMargins(16, 14, 16, 14)
        accent_layout.setSpacing(7)
        self._setting_row(accent_layout, 'ACCENT GRADIENT', 'Set two colors for buttons, sliders, and active controls.')
        self.accent_start_input = self._color_input_row(accent_layout, 'Start', self.accent_gradient_start)
        self.accent_end_input = self._color_input_row(accent_layout, 'End', self.accent_gradient_end)
        apply_gradient = QPushButton('APPLY ACCENT GRADIENT')
        apply_gradient.setObjectName('secondaryButton')
        apply_gradient.clicked.connect(self._apply_accent_gradient)
        accent_layout.addWidget(apply_gradient, alignment=Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(accent_colors)

        customization_panel = self._settings_panel()
        customization_layout = QVBoxLayout(customization_panel)
        customization_layout.setContentsMargins(18, 18, 18, 18)
        customization_layout.setSpacing(9)
        self._setting_row(
            customization_layout,
            'CUSTOM CSS & PLUGINS',
            'Add Qt stylesheets in the editor or load .qss plugins from the local plugins folder. CSS plugins cannot run code.',
        )
        self.custom_css_editor = QPlainTextEdit()
        self.custom_css_editor.setPlaceholderText(
            'Example:\nQPushButton#playButton {\n    border-radius: 8px;\n}'
        )
        self.custom_css_editor.setPlainText(self.custom_stylesheet)
        self.custom_css_editor.setMinimumHeight(140)
        self.custom_css_editor.setMaximumHeight(240)
        self.custom_css_editor.setFont(QFont('Consolas', 10))
        customization_layout.addWidget(self.custom_css_editor)
        css_actions = QHBoxLayout()
        apply_css = QPushButton('APPLY CUSTOM CSS')
        apply_css.setObjectName('accentButton')
        apply_css.clicked.connect(self._apply_custom_stylesheet)
        css_actions.addWidget(apply_css)
        clear_css = QPushButton('CLEAR EDITOR')
        clear_css.setObjectName('secondaryButton')
        clear_css.clicked.connect(self._clear_custom_stylesheet)
        css_actions.addWidget(clear_css)
        install_plugin = QPushButton('INSTALL .QSS PLUGIN')
        install_plugin.setObjectName('secondaryButton')
        install_plugin.clicked.connect(self._install_css_plugin)
        css_actions.addWidget(install_plugin)
        open_plugins = QPushButton('OPEN PLUGINS FOLDER')
        open_plugins.setObjectName('secondaryButton')
        open_plugins.clicked.connect(self._open_css_plugins_folder)
        css_actions.addWidget(open_plugins)
        reload_plugins = QPushButton('RELOAD PLUGINS')
        reload_plugins.setObjectName('secondaryButton')
        reload_plugins.clicked.connect(self._refresh_css_plugins)
        css_actions.addWidget(reload_plugins)
        customization_layout.addLayout(css_actions)
        self.plugin_status_label = QLabel(self.plugin_status or 'No CSS plugins loaded.')
        self.plugin_status_label.setWordWrap(True)
        self.plugin_status_label.setStyleSheet(f'color:{self.muted};font-size:11px;')
        customization_layout.addWidget(self.plugin_status_label)
        layout.addWidget(customization_panel)

        background_panel = self._settings_panel()
        background_layout = QVBoxLayout(background_panel)
        background_layout.setContentsMargins(18, 18, 18, 18)
        background_layout.setSpacing(10)
        self._setting_row(background_layout, 'CUSTOM BACKGROUND', 'Use a still image or animated GIF. It is scaled to fill the window and stays on this device.')
        background_actions = QHBoxLayout()
        choose_background = QPushButton('CHOOSE IMAGE OR GIF')
        choose_background.setObjectName('accentButton')
        choose_background.clicked.connect(self._choose_background)
        background_actions.addWidget(choose_background)
        clear_background = QPushButton('REMOVE')
        clear_background.setObjectName('secondaryButton')
        clear_background.clicked.connect(self._clear_background)
        background_actions.addWidget(clear_background)
        background_actions.addStretch(1)
        background_layout.addLayout(background_actions)
        self._background_path_label = QLabel(Path(self.background_path).name if self.background_path else 'Using the selected theme color')
        self._background_path_label.setStyleSheet(f'color:{self.muted};font-size:11px;')
        self._background_path_label.setWordWrap(True)
        background_layout.addWidget(self._background_path_label)
        self._setting_row(background_layout, 'BACKGROUND DIMMING', 'Adjust how visible the uploaded image appears behind the interface.')
        opacity_row = QHBoxLayout()
        self.background_opacity_slider = QSlider(Qt.Orientation.Horizontal)
        self.background_opacity_slider.setRange(0, 90)
        self.background_opacity_slider.setValue(self.background_opacity)
        self.background_opacity_slider.valueChanged.connect(self._change_background_opacity)
        opacity_row.addWidget(self.background_opacity_slider, 1)
        self.background_opacity_label = QLabel(f'{self.background_opacity}%')
        self.background_opacity_label.setMinimumWidth(42)
        self.background_opacity_label.setStyleSheet(f'color:{self.muted};')
        opacity_row.addWidget(self.background_opacity_label)
        background_layout.addLayout(opacity_row)
        layout.addWidget(background_panel)

        cursor_panel = self._settings_panel()
        cursor_layout = QVBoxLayout(cursor_panel)
        cursor_layout.setContentsMargins(18, 18, 18, 18)
        cursor_layout.setSpacing(10)
        self._setting_row(cursor_layout, 'CUSTOM CURSOR', 'Choose a cursor image. It is scaled to a readable 32 × 32 pixels.')
        cursor_actions = QHBoxLayout()
        choose_cursor = QPushButton('CHOOSE CURSOR IMAGE')
        choose_cursor.setObjectName('secondaryButton')
        choose_cursor.clicked.connect(self._choose_cursor)
        cursor_actions.addWidget(choose_cursor)
        reset_cursor = QPushButton('RESET TO DEFAULT')
        reset_cursor.setObjectName('secondaryButton')
        reset_cursor.clicked.connect(self._clear_cursor)
        cursor_actions.addWidget(reset_cursor)
        cursor_actions.addStretch(1)
        cursor_layout.addLayout(cursor_actions)
        self._cursor_path_label = QLabel(Path(self.cursor_path).name if self.cursor_path else 'Using the system cursor')
        self._cursor_path_label.setStyleSheet(f'color:{self.muted};font-size:11px;')
        self._cursor_path_label.setWordWrap(True)
        cursor_layout.addWidget(self._cursor_path_label)
        layout.addWidget(cursor_panel)

        layout.addStretch(1)
        self._activate_page(page)

    def _color_input_row(self, layout, label, value):
        row = QHBoxLayout()
        title = QLabel(label)
        title.setMinimumWidth(80)
        title.setStyleSheet(f'color:{self.muted};font-size:11px;')
        row.addWidget(title)
        field = QLineEdit(value)
        field.setPlaceholderText('#RRGGBB or rgb(255, 120, 40)')
        field.setObjectName('colorValueInput')
        row.addWidget(field, 1)
        layout.addLayout(row)
        return field

    def _apply_custom_theme(self):
        keys = ('background', 'surface', 'card', 'text', 'muted')
        colors = {}
        invalid = []
        for key, field in self.custom_theme_inputs.items():
            color = parse_color(field.text())
            if color is None:
                invalid.append(key.title())
            else:
                colors[key] = color.name()
        if invalid:
            QMessageBox.warning(
                self,
                'Invalid theme color',
                f'Enter a valid HEX, rgb(), or comma-separated RGB value for: {", ".join(invalid)}.',
            )
            return
        self.custom_theme_palette = tuple(colors[key] for key in keys)
        self.custom_theme_active = True
        self.theme_name = 'Custom'
        self.bg, self.surface, self.card, self.text_color, self.muted = self.custom_theme_palette
        self._apply_styles()
        self._save_state()
        self._show_settings()

    def _apply_accent_gradient(self):
        start = parse_color(self.accent_start_input.text())
        end = parse_color(self.accent_end_input.text())
        if start is None or end is None:
            QMessageBox.warning(
                self,
                'Invalid accent color',
                'Enter valid HEX, rgb(), or comma-separated RGB values for both gradient colors.',
            )
            return
        self.accent_gradient_start = start.name()
        self.accent_gradient_end = end.name()
        self.accent = self.accent_gradient_start
        self.accent_fill = (
            f'qlineargradient(x1:0, y1:0, x2:1, y2:0, '
            f'stop:0 {self.accent_gradient_start}, stop:1 {self.accent_gradient_end})'
        )
        self.accent_name = 'Custom Gradient'
        self._apply_styles()
        self._save_state()
        self._show_settings()

    def _reload_css_plugins(self):
        plugin_stylesheets = []
        plugin_names = []
        errors = []
        if CSS_PLUGINS_DIR.is_dir():
            for path in sorted(CSS_PLUGINS_DIR.glob('*.qss'), key=lambda item: item.name.casefold()):
                try:
                    if path.stat().st_size > 256 * 1024:
                        errors.append(f'{path.name}: stylesheet exceeds 256 KB.')
                        continue
                    stylesheet = path.read_text(encoding='utf-8')
                except (OSError, UnicodeError) as exc:
                    errors.append(f'{path.name}: {exc}')
                    continue
                validation_error = validate_stylesheet(stylesheet)
                if validation_error:
                    errors.append(f'{path.name}: {validation_error}')
                    continue
                plugin_stylesheets.append(stylesheet)
                plugin_names.append(path.name)
        self.plugin_stylesheet = '\n'.join(plugin_stylesheets)
        if plugin_stylesheets:
            self.plugin_status = f'Loaded {len(plugin_stylesheets)} CSS plugin(s): {", ".join(plugin_names)}.'
        else:
            self.plugin_status = f'No CSS plugins loaded. Folder: {CSS_PLUGINS_DIR}'
        if errors:
            self.plugin_status += '\nPlugin issues: ' + ' | '.join(errors[:5])

    def _change_font_family(self, font):
        family = font.family()
        if not family or family == self.font_family:
            return
        self.font_family = family
        app = QApplication.instance()
        if app:
            application_font = app.font()
            application_font.setFamily(family)
            app.setFont(application_font)
        self._save_state()

    def _apply_custom_stylesheet(self):
        stylesheet = self.custom_css_editor.toPlainText()
        validation_error = validate_stylesheet(stylesheet)
        if validation_error:
            QMessageBox.warning(self, 'Custom CSS could not be applied', validation_error)
            return
        self.custom_stylesheet = stylesheet
        self._apply_styles()
        self._save_state()
        self._show_settings()

    def _clear_custom_stylesheet(self):
        self.custom_css_editor.clear()
        self.custom_stylesheet = ''
        self._apply_styles()
        self._save_state()
        self._show_settings()

    def _install_css_plugin(self):
        source, _filter = QFileDialog.getOpenFileName(
            self,
            'Install a CSS plugin',
            '',
            'Qt stylesheets (*.qss)',
        )
        if not source:
            return
        source_path = Path(source)
        try:
            stylesheet = source_path.read_text(encoding='utf-8')
        except (OSError, UnicodeError) as exc:
            QMessageBox.warning(self, 'Plugin could not be read', str(exc))
            return
        validation_error = validate_stylesheet(stylesheet)
        if validation_error:
            QMessageBox.warning(self, 'Plugin stylesheet is invalid', validation_error)
            return
        try:
            CSS_PLUGINS_DIR.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            QMessageBox.warning(self, 'Plugins folder could not be created', str(exc))
            return
        destination = CSS_PLUGINS_DIR / source_path.name
        if destination.exists():
            answer = QMessageBox.question(
                self,
                'Replace CSS plugin?',
                f'{destination.name} already exists. Replace it?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if answer != QMessageBox.StandardButton.Yes:
                return
        try:
            shutil.copy2(source_path, destination)
        except OSError as exc:
            QMessageBox.warning(self, 'Plugin could not be installed', str(exc))
            return
        self._reload_css_plugins()
        self._apply_styles()
        self._save_state()
        self._show_settings()

    def _open_css_plugins_folder(self):
        try:
            CSS_PLUGINS_DIR.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            QMessageBox.warning(self, 'Plugins folder could not be opened', str(exc))
            return
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(CSS_PLUGINS_DIR.resolve()))):
            QMessageBox.warning(self, 'Plugins folder could not be opened', str(CSS_PLUGINS_DIR))

    def _refresh_css_plugins(self):
        self._reload_css_plugins()
        self._apply_styles()
        self._show_settings()

    def _set_hud_off(self, enabled):
        self.hud_off = enabled
        self._apply_hud_visibility()
        self._save_state()

    def _set_compact_mode(self, enabled):
        self.compact_mode = enabled
        self._apply_compact_layout()
        self._save_state()

    def _apply_compact_layout(self):
        if not hasattr(self, 'workspace_layout'):
            return
        compact = self.compact_mode
        self.sidebar.setFixedWidth(138 if compact else 172)
        if compact:
            self.workspace_layout.setContentsMargins(10, 8, 10, 6)
            self.player_layout.setContentsMargins(8, 5, 8, 5)
        else:
            self.workspace_layout.setContentsMargins(20, 12, 20, 10)
            self.player_layout.setContentsMargins(12, 8, 12, 8)
        self.workspace_layout.setSpacing(5 if compact else 8)
        self.player_layout.setSpacing(5 if compact else 8)
        self.cover_thumb.setFixedSize(36 if compact else 42, 36 if compact else 42)
        self.seek_slider.setMinimumWidth(48 if compact else 64)
        self.seek_slider.setMaximumWidth(130 if compact else 160)
        self.volume_slider.setFixedWidth(44 if compact else 52)

    def _set_fullscreen_mode(self, enabled):
        self.fullscreen_mode = enabled
        if enabled and not self.isFullScreen():
            self._windowed_geometry = self.saveGeometry()
            self.showFullScreen()
        elif not enabled and self.isFullScreen():
            self.showNormal()
            if self._windowed_geometry:
                self.restoreGeometry(self._windowed_geometry)
        self._save_state()

    def _toggle_fullscreen(self):
        enabled = not self.isFullScreen()
        self._set_fullscreen_mode(enabled)
        if hasattr(self, 'fullscreen_checkbox'):
            previous = self.fullscreen_checkbox.blockSignals(True)
            self.fullscreen_checkbox.setChecked(enabled)
            self.fullscreen_checkbox.blockSignals(previous)

    def _change_appearance_style(self, name):
        if name not in APPEARANCE_STYLES:
            return
        self.appearance_style = name
        self._apply_styles()
        self._save_state()
        self._show_settings()

    def _toggle_hud(self):
        self._set_hud_off(not self.hud_off)
        if hasattr(self, 'hud_checkbox'):
            previous = self.hud_checkbox.blockSignals(True)
            self.hud_checkbox.setChecked(self.hud_off)
            self.hud_checkbox.blockSignals(previous)

    def _apply_hud_visibility(self):
        if not hasattr(self, 'topbar'):
            return
        self.sidebar.setVisible(not self.hud_off)
        self.topbar.setVisible(not self.hud_off)
        self.statusBar().setVisible(not self.hud_off)

    def _settings_panel(self):
        panel = QFrame()
        if self.appearance_style == 'Liquid Glass':
            panel.setStyleSheet('QFrame { background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 rgba(255,255,255,34), stop:1 rgba(255,255,255,12)); border: 1px solid rgba(255,255,255,60); border-radius: 12px; }')
        else:
            panel.setStyleSheet(f'QFrame {{ background: {self.surface}; border: 1px solid rgba(255,255,255,28); border-radius: 10px; }}')
        return panel

    def _surface_fill(self):
        if self.appearance_style == 'Liquid Glass':
            return 'qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 rgba(255,255,255,30), stop:1 rgba(255,255,255,10))'
        return self.surface

    def _setting_row(self, layout, title, description):
        title_label = QLabel(title)
        title_label.setStyleSheet(f'color:{self.text_color};font-size:13px;font-weight:800;letter-spacing:1px;')
        layout.addWidget(title_label)
        desc = QLabel(description)
        desc.setStyleSheet(f'color:{self.muted};font-size:11px;')
        layout.addWidget(desc)

    def _choose_background(self):
        path, _filter = QFileDialog.getOpenFileName(
            self,
            'Choose a background image or GIF',
            '',
            'Images and GIFs (*.png *.jpg *.jpeg *.bmp *.webp *.gif)',
        )
        if not path:
            return
        try:
            stored_path = self._store_project_asset(Path(path), BACKGROUNDS_DIR)
        except OSError as exc:
            QMessageBox.warning(self, 'Background could not be saved', str(exc))
            return
        try:
            self.root_widget.set_background(str(stored_path), self.background_opacity)
        except ValueError as exc:
            QMessageBox.warning(self, 'Background could not be loaded', str(exc))
            return
        self.background_path = str(stored_path)
        self._background_path_label.setText(stored_path.name)
        self._save_state()

    def _clear_background(self):
        self.root_widget.set_background('', self.background_opacity)
        self.background_path = ''
        self._background_path_label.setText('Using the selected theme color')
        self._save_state()

    def _change_background_opacity(self, value):
        self.background_opacity = value
        self.background_opacity_label.setText(f'{value}%')
        self.root_widget.set_overlay_opacity(value)
        self._save_state()

    def _choose_cursor(self):
        path, _filter = QFileDialog.getOpenFileName(
            self,
            'Choose a cursor image',
            '',
            'Cursor images (*.png *.jpg *.jpeg *.bmp *.webp *.ico)',
        )
        if not path:
            return
        previous_path = self.cursor_path
        try:
            stored_path = self._store_project_asset(Path(path), CURSORS_DIR)
        except OSError as exc:
            QMessageBox.warning(self, 'Cursor could not be saved', str(exc))
            return
        self.cursor_path = str(stored_path)
        if not self._apply_custom_cursor():
            self.cursor_path = previous_path
            self._apply_custom_cursor()
            return
        self._cursor_path_label.setText(stored_path.name)
        self._save_state()

    def _store_project_asset(self, source, destination_dir):
        source = source.expanduser().resolve(strict=True)
        if not source.is_file():
            raise OSError(f'Not a file: {source}')
        destination_dir.mkdir(parents=True, exist_ok=True)
        destination_root = destination_dir.resolve()
        try:
            source.relative_to(destination_root)
            return source
        except ValueError:
            pass

        digest = hashlib.sha256()
        with source.open('rb') as asset:
            for chunk in iter(lambda: asset.read(1024 * 1024), b''):
                digest.update(chunk)
        destination = destination_dir / f'{source.stem}-{digest.hexdigest()[:12]}{source.suffix.lower()}'
        if not destination.exists():
            shutil.copy2(source, destination)
        return destination.resolve()

    def _clear_cursor(self):
        self.cursor_path = ''
        self._apply_custom_cursor()
        self._cursor_path_label.setText('Using the system cursor')
        self._save_state()

    def _apply_custom_cursor(self):
        if self._cursor_overridden:
            QApplication.restoreOverrideCursor()
            self._cursor_overridden = False
        if not self.cursor_path:
            return True
        pixmap = QPixmap(self.cursor_path)
        if pixmap.isNull():
            QMessageBox.warning(self, 'Cursor could not be loaded', 'Choose a valid PNG, JPEG, BMP, WebP, or ICO image.')
            return False
        cursor_pixmap = pixmap.scaled(
            32,
            32,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        QApplication.setOverrideCursor(QCursor(cursor_pixmap, 0, 0))
        self._cursor_overridden = True
        return True

    def _change_theme(self, name):
        self.theme_name = name
        self.custom_theme_active = name == 'Custom'
        if self.custom_theme_active:
            self.bg, self.surface, self.card, self.text_color, self.muted = self.custom_theme_palette
        else:
            self.bg, self.surface, self.card, self.text_color, self.muted = THEMES[name]
        self._apply_styles()
        self._save_state()
        self._show_page('Settings')

    def _change_accent(self, name):
        self.accent_name = name
        if name in ACCENTS:
            self.accent_gradient_start = ACCENTS[name]
            self.accent_gradient_end = ACCENTS[name]
        self.accent = self.accent_gradient_start
        self.accent_fill = (
            f'qlineargradient(x1:0, y1:0, x2:1, y2:0, '
            f'stop:0 {self.accent_gradient_start}, stop:1 {self.accent_gradient_end})'
        )
        self._apply_styles()
        self._save_state()
        self._show_page('Settings')

    def _import_files(self):
        names, _filter = QFileDialog.getOpenFileNames(self, 'Add local audio', '', 'Audio files (*.wav *.mp3 *.ogg)')
        self._add_files([Path(name) for name in names])

    def _import_folder(self):
        folder = QFileDialog.getExistingDirectory(self, 'Import a music folder')
        if not folder:
            return
        try:
            paths = [path for path in Path(folder).rglob('*') if path.is_file() and path.suffix.lower() in SUPPORTED_AUDIO]
        except OSError as exc:
            QMessageBox.warning(self, 'Folder import failed', str(exc))
            return
        self._add_files(paths)

    def _track_for_file(self, path):
        title, artist, album, year, duration, art_path = metadata_for_file(path)
        if not art_path:
            art_path = str(generated_cover_for_file(path))
        return Track(
            title=title,
            path=str(path.resolve()),
            artist=artist,
            duration=duration,
            source='Local',
            art_path=art_path,
            album=album,
            year=year,
        )

    def _add_files(self, paths):
        known = {track.key for track in self.library}
        added = 0
        failures = []
        for path in paths:
            if path.is_file() and path.suffix.lower() in SUPPORTED_AUDIO:
                try:
                    stored_path = self._store_project_asset(path, MUSIC_DIR)
                    track = self._track_for_file(stored_path)
                    override = self.artwork_overrides.get(track.key)
                    if override and Path(override).is_file():
                        track.art_path = override
                    if track.key not in known:
                        self.library.append(track)
                        known.add(track.key)
                        added += 1
                except OSError as exc:
                    failures.append(f'{path.name}: {exc}')
        if added:
            self._save_state()
            self._set_status(f'ADDED {added} LOCAL TRACKS')
            self._show_page('Your Library')
        elif paths:
            self._set_status('NO NEW SUPPORTED AUDIO FILES FOUND')
        if failures:
            QMessageBox.warning(self, 'Some audio files could not be copied', '\n'.join(failures[:10]))

    def _download_audio_url(self):
        worker = getattr(self, '_download_worker', None)
        if worker and worker.isRunning():
            self._set_status('AN AUDIO DOWNLOAD IS ALREADY RUNNING')
            return
        url, accepted = QInputDialog.getText(
            self,
            'Download audio for offline playback',
            'Direct HTTPS link to an MP3, WAV, or OGG file you are authorized to save:',
        )
        if not accepted:
            return
        if urlsplit(url.strip()).scheme.casefold() != 'https':
            QMessageBox.warning(self, 'HTTPS URL required', 'Use a direct HTTPS audio-file URL.')
            return

        self._download_dialog = QProgressDialog(
            'Downloading an authorized audio file…',
            'Cancel',
            0,
            100,
            self,
        )
        self._download_dialog.setWindowTitle('Download audio')
        self._download_dialog.setWindowModality(Qt.WindowModality.WindowModal)
        self._download_dialog.setMinimumDuration(0)
        worker = DirectAudioDownloadWorker(url.strip(), self)
        self._download_worker = worker
        self._download_dialog.canceled.connect(worker.requestInterruption)
        worker.progress_changed.connect(self._update_download_progress)
        worker.completed.connect(self._handle_audio_download)
        worker.finished.connect(lambda current=worker: self._clear_worker_reference('_download_worker', current))
        worker.start()
        self._set_status('DOWNLOADING AUDIO FILE')

    def _update_download_progress(self, progress):
        dialog = getattr(self, '_download_dialog', None)
        if not dialog:
            return
        if progress < 0:
            dialog.setRange(0, 0)
        else:
            if dialog.maximum() == 0:
                dialog.setRange(0, 100)
            dialog.setValue(progress)

    def _handle_audio_download(self, path, error):
        dialog = getattr(self, '_download_dialog', None)
        if dialog:
            dialog.close()
            dialog.deleteLater()
            self._download_dialog = None
        if error:
            if error != 'Download canceled.':
                QMessageBox.warning(self, 'Audio download failed', error)
            self._set_status('AUDIO DOWNLOAD CANCELED' if error == 'Download canceled.' else 'AUDIO DOWNLOAD FAILED')
            return
        downloaded_path = Path(path)
        try:
            self._add_files([downloaded_path])
        finally:
            downloaded_path.unlink(missing_ok=True)

    def _clear_worker_reference(self, attribute, worker):
        if getattr(self, attribute, None) is worker:
            setattr(self, attribute, None)
            worker.deleteLater()

    def _edit_track_metadata(self, track):
        if not track.path or not Path(track.path).is_file():
            QMessageBox.warning(self, 'Track unavailable', 'Metadata can only be edited for an available local audio file.')
            return
        dialog = QDialog(self)
        dialog.setWindowTitle(f'Edit metadata · {track.title}')
        form = QFormLayout(dialog)
        fields = {}
        for key, label, value in (
            ('title', 'Title', track.title),
            ('artist', 'Artist', track.artist),
            ('album', 'Album', track.album),
            ('year', 'Year', track.year),
        ):
            field = QLineEdit(value)
            fields[key] = field
            form.addRow(label, field)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel,
            parent=dialog,
        )
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        title = fields['title'].text().strip()
        artist = fields['artist'].text().strip()
        if not title or not artist:
            QMessageBox.warning(self, 'Metadata required', 'Track title and artist cannot be empty.')
            return
        album = fields['album'].text().strip()
        year = fields['year'].text().strip()
        try:
            write_track_metadata(track.path, title, artist, album, year)
        except (OSError, ValueError, TypeError, KeyError) as exc:
            QMessageBox.warning(self, 'Metadata could not be saved', str(exc))
            return
        track.title, track.artist, track.album, track.year = title, artist, album, year
        self._refresh_track_views(track)
        self._set_status(f'SAVED METADATA · {track.title.upper()}')

    def _choose_track_artwork(self, track):
        path, _filter = QFileDialog.getOpenFileName(
            self,
            f'Choose cover art · {track.title}',
            '',
            'Image files (*.png *.jpg *.jpeg *.bmp *.webp)',
        )
        if path:
            self._set_track_artwork(track, Path(path))

    def _set_track_artwork(self, track, source_path):
        try:
            if source_path.stat().st_size > MAX_COVER_DOWNLOAD_BYTES:
                raise ValueError('Cover images must be smaller than 15 MB.')
            image = QImage(str(source_path))
            if image.isNull():
                raise ValueError('The selected cover image could not be opened.')
            image_dir = APP_DIR / 'artwork'
            image_dir.mkdir(parents=True, exist_ok=True)
            digest = hashlib.sha256(
                track.key.encode('utf-8') + source_path.read_bytes()
            ).hexdigest()
            destination = image_dir / f'{digest}.png'
            if not image.save(str(destination), 'PNG'):
                raise OSError(f'Could not save cover art to {destination}.')
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, 'Cover art could not be saved', str(exc))
            return
        try:
            embed_cover_art(track.path, destination)
        except (OSError, ValueError, TypeError, KeyError) as exc:
            QMessageBox.warning(
                self,
                'Cover art could not be embedded',
                f'The image will still be used in UNDERGROUND, but could not be written into the audio file:\n{exc}',
            )
        track.art_path = str(destination)
        self.artwork_overrides[track.key] = str(destination)
        self._refresh_track_views(track)
        self._set_status(f'UPDATED COVER ART · {track.title.upper()}')

    def _lookup_online_metadata(self, track):
        worker = getattr(self, '_metadata_lookup_worker', None)
        if worker and worker.isRunning():
            self._set_status('A METADATA LOOKUP IS ALREADY RUNNING')
            return
        worker = OnlineMetadataLookupWorker(track.title, track.artist, self)
        self._metadata_lookup_worker = worker
        worker.completed.connect(
            lambda candidates, error, item=track:
            self._handle_online_metadata_result(item, candidates, error)
        )
        worker.finished.connect(
            lambda current=worker:
            self._clear_worker_reference('_metadata_lookup_worker', current)
        )
        worker.start()
        self._set_status(f'LOOKING UP METADATA · {track.title.upper()}')

    def _handle_online_metadata_result(self, track, candidates, error):
        if error:
            QMessageBox.warning(self, 'Metadata lookup failed', error)
            self._set_status('METADATA LOOKUP FAILED')
            return
        if not candidates:
            QMessageBox.information(self, 'No matches found', 'MusicBrainz did not find matching recording metadata.')
            return
        choices = [
            ' — '.join(
                part for part in (
                    candidate['title'],
                    candidate['artist'],
                    candidate['album'],
                    candidate['year'],
                ) if part
            )
            for candidate in candidates
        ]
        selection, accepted = QInputDialog.getItem(
            self,
            'Choose matching metadata',
            'MusicBrainz matches:',
            choices,
            0,
            False,
        )
        if not accepted:
            return
        candidate = candidates[choices.index(selection)]
        title = candidate['title'] or track.title
        artist = candidate['artist'] or track.artist
        album = candidate['album'] or track.album
        year = candidate['year'] or track.year
        try:
            write_track_metadata(track.path, title, artist, album, year)
        except (OSError, ValueError, TypeError, KeyError) as exc:
            QMessageBox.warning(self, 'Metadata could not be saved', str(exc))
            return
        track.title, track.artist, track.album, track.year = title, artist, album, year
        self._refresh_track_views(track)
        self._set_status(f'UPDATED METADATA · {track.title.upper()}')
        if candidate['cover_url']:
            answer = QMessageBox.question(
                self,
                'Download matching cover art?',
                'Download this release cover from the Cover Art Archive and embed it in the local audio file?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes,
            )
            if answer == QMessageBox.StandardButton.Yes:
                self._download_matching_cover(track, candidate['cover_url'])

    def _download_matching_cover(self, track, url):
        digest = hashlib.sha256((track.key + url).encode('utf-8')).hexdigest()
        destination = APP_DIR / 'artwork' / f'{digest}.png'
        worker = CoverArtDownloadWorker(url, destination, self)
        if not hasattr(self, '_cover_art_workers'):
            self._cover_art_workers = []
        self._cover_art_workers.append(worker)
        worker.completed.connect(
            lambda path, error, item=track:
            self._handle_matching_cover(item, path, error)
        )
        worker.finished.connect(
            lambda current=worker: self._finish_cover_art_worker(current)
        )
        worker.start()
        self._set_status(f'DOWNLOADING COVER ART · {track.title.upper()}')

    def _finish_cover_art_worker(self, worker):
        workers = getattr(self, '_cover_art_workers', [])
        if worker in workers:
            workers.remove(worker)
        worker.deleteLater()

    def _handle_matching_cover(self, track, path, error):
        if error:
            QMessageBox.warning(self, 'Cover art download failed', error)
            return
        self._set_track_artwork(track, Path(path))

    def _refresh_track_views(self, track):
        if self.current_track and self.current_track.key == track.key:
            self._update_player(track)
        current_page = self.pages.currentWidget() if hasattr(self, 'pages') else None
        page_name = next(
            (name for name, page in self.page_widgets.items() if page is current_page),
            'Your Library',
        )
        self._save_state()
        self._show_page(page_name)

    def _create_playlist_with_track(self, track):
        name, accepted = QInputDialog.getText(
            self,
            'Create playlist',
            'Playlist name:',
        )
        name = name.strip()
        if not accepted or not name:
            return
        if name in self.playlists:
            QMessageBox.warning(self, 'Playlist already exists', f'A playlist named “{name}” already exists.')
            return
        self.playlists[name] = [track.key]
        self._save_state()
        self._show_playlist_contents(name)

    def _add_track_to_playlist(self, name, track):
        if name not in self.playlists:
            QMessageBox.warning(self, 'Playlist unavailable', f'Could not find the playlist “{name}”.')
            return
        keys = self.playlists[name]
        if track.key in keys:
            self._set_status(f'ALREADY IN PLAYLIST · {name.upper()}')
            return
        keys.append(track.key)
        self._save_state()
        self._set_status(f'ADDED {track.title.upper()} TO {name.upper()}')

    def _play(self, track):
        if self.audio_error:
            self._set_status(f'AUDIO DEVICE UNAVAILABLE · {self.audio_error}')
            return
        self._stop_local()
        try:
            pygame.mixer.music.load(track.path)
            pygame.mixer.music.set_volume(self.volume)
            pygame.mixer.music.play()
        except pygame.error as exc:
            self._set_status(f'COULD NOT PLAY {track.title.upper()} · {exc}')
            return
        self.current_track = track
        self.playing = True
        self.paused = False
        self.position_offset = 0.0
        if not any(item.key == track.key for item in self.queue):
            self.queue = [item for item in self.queue if item.key != track.key]
        self._update_player(track)
        self._record_history(track)
        self._set_status(f'LOCAL PLAYBACK · {track.title.upper()}')

    def _update_player(self, track):
        self.track_label.setText(track.title.upper())
        self.artist_label.setText(f'{track.artist}  ·  {track.album}' if track.album else track.artist.upper())
        art = self._find_art(track)
        if art:
            self.cover_thumb.setPixmap(QPixmap(str(art)).scaled(54, 54, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation))
            self.cover_thumb.setText('')
        else:
            self.cover_thumb.setPixmap(QPixmap())
            self.cover_thumb.setText('U')
        self.total_label.setText(fmt_time(track.duration))
        self.seek_slider.setEnabled(track.duration > 0)
        self.play_button.setEnabled(True)
        self.play_button.setToolTip('Play or pause local audio (Space)')
        self.play_button.setText('Ⅱ' if self.playing else '▶')

    def _stop_local(self):
        if pygame.mixer.get_init():
            pygame.mixer.music.stop()
        self.playing = False
        self.paused = False

    def _toggle_play(self):
        if not self.current_track:
            if self.library:
                self._play(self.library[0])
            return
        if self.playing:
            pygame.mixer.music.pause()
            self.playing = False
            self.paused = True
        elif self.paused:
            pygame.mixer.music.unpause()
            self.playing = True
            self.paused = False
        else:
            self._play(self.current_track)
            return
        self.play_button.setText('Ⅱ' if self.playing else '▶')

    def _next(self):
        if self.queue:
            target = self.queue.pop(0)
            self._play(target)
            return
        playable = self.library
        if not playable:
            self._set_status('LIBRARY IS EMPTY · IMPORT A MUSIC FOLDER')
            return
        index = playable.index(self.current_track) if self.current_track in playable else -1
        self._play(random.choice(playable) if self.shuffle else playable[(index + 1) % len(playable)])

    def _previous(self):
        if self.current_track and self.position_offset > 3:
            self._seek_to(0)
            return
        playable = self.library
        if playable:
            index = playable.index(self.current_track) if self.current_track in playable else 0
            self._play(playable[(index - 1) % len(playable)])

    def _toggle_shuffle(self):
        self.shuffle = not self.shuffle
        self.shuffle_button.setStyleSheet(f'color:{self.accent if self.shuffle else self.text_color};')
        self._set_status('SHUFFLE ON' if self.shuffle else 'SHUFFLE OFF')

    def _toggle_repeat(self):
        self.repeat = not self.repeat
        self.repeat_button.setStyleSheet(f'color:{self.accent if self.repeat else self.text_color};')
        self._set_status('REPEAT ON' if self.repeat else 'REPEAT OFF')

    def _set_volume(self, value):
        self.volume = value / 100
        if pygame.mixer.get_init():
            pygame.mixer.music.set_volume(self.volume)
        self._save_state()

    def _tick(self):
        if not self.current_track or not self.playing:
            return
        position_ms = pygame.mixer.music.get_pos()
        if position_ms >= 0:
            self.position_offset = position_ms / 1000
        self.elapsed_label.setText(fmt_time(self.position_offset))
        if self.current_track.duration:
            self.total_label.setText(fmt_time(self.current_track.duration))
            if not self.scrubbing:
                self.seek_slider.setValue(int(1000 * self.position_offset / self.current_track.duration))
        if not pygame.mixer.music.get_busy():
            if self.repeat:
                self._play(self.current_track)
            else:
                self.playing = False
                self.play_button.setText('▶')
                self._next()

    def _seek(self):
        if self.current_track and self.current_track.duration:
            self._seek_to(self.seek_slider.value() / 1000 * self.current_track.duration)
        self.scrubbing = False

    def _seek_to(self, seconds):
        if not self.current_track or not self.current_track.duration:
            return
        was_playing = self.playing
        try:
            pygame.mixer.music.play(start=max(0, min(seconds, self.current_track.duration)))
            self.position_offset = seconds
            self.playing = True
            self.paused = False
            if not was_playing:
                pygame.mixer.music.pause()
                self.playing = False
                self.paused = True
            self.play_button.setText('Ⅱ' if self.playing else '▶')
        except pygame.error as exc:
            self._set_status(f'SEEK FAILED · {exc}')

    def _enqueue(self, track):
        if track not in self.queue:
            self.queue.append(track)
            self._set_status(f'QUEUED · {track.title.upper()}')

    def _show_queue(self, record_history=True):
        if record_history:
            self._record_navigation('Queue')
        page = self._page('Queue')
        self._clear_page(page)
        layout = page._layout
        self._header(layout, 'Up next', 'Queue', f'{len(self.queue)} queued items')
        if not self.queue:
            layout.addWidget(QLabel('Queue is empty. Press + on a library track to add it.'))
        for index, track in enumerate(self.queue):
            row = self._track_row(track)
            layout.addWidget(row)
            move = QPushButton(f'MOVE UP  ↑   {index + 1}')
            move.setObjectName('secondaryButton')
            move.clicked.connect(lambda _checked=False, i=index: self._move_queue(i))
            layout.addWidget(move, alignment=Qt.AlignmentFlag.AlignRight)
        clear = QPushButton('CLEAR QUEUE')
        clear.setObjectName('secondaryButton')
        clear.clicked.connect(self._clear_queue)
        layout.addWidget(clear, alignment=Qt.AlignmentFlag.AlignLeft)
        self._activate_page(page)

    def _move_queue(self, index):
        if index <= 0 or index >= len(self.queue):
            return
        self.queue[index - 1], self.queue[index] = self.queue[index], self.queue[index - 1]
        self._show_queue()

    def _clear_queue(self):
        self.queue.clear()
        self._show_queue()

    def _toggle_like(self, track):
        if track.key in self.favorites:
            self.favorites.remove(track.key)
        else:
            self.favorites.add(track.key)
        self._save_state()
        current = self.pages.currentWidget()
        if current:
            self._show_page('Liked Songs' if current is self.page_widgets.get('Liked Songs') else 'Your Library')

    def _record_history(self, track):
        self.history = [key for key in self.history if key != track.key]
        self.history.insert(0, track.key)
        self.history = self.history[:60]
        self._save_state()

    def _track_by_key(self, key):
        return next((track for track in self.library if track.key == key), None)

    def _create_playlist(self):
        from PySide6.QtWidgets import QInputDialog
        name, ok = QInputDialog.getText(self, 'New playlist', 'Playlist name:')
        name = name.strip()
        if ok and name and name not in self.playlists:
            self.playlists[name] = []
            self._save_state()
            self._show_page('Playlists')

    def _add_to_playlist(self, name):
        if not self.current_track:
            self._set_status('PLAY A TRACK FIRST')
            return
        keys = self.playlists[name]
        if self.current_track.key not in keys:
            keys.append(self.current_track.key)
            self._save_state()
            self._show_page('Playlists')

    def _play_playlist(self, name):
        tracks = [self._track_by_key(key) for key in self.playlists[name]]
        tracks = [track for track in tracks if track]
        if not tracks:
            self._set_status('THIS PLAYLIST HAS NO AVAILABLE ITEMS')
            return
        self.queue = tracks[1:]
        self._play(tracks[0])

    def _delete_playlist(self, name):
        answer = QMessageBox.question(self, 'Delete playlist', f'Delete “{name}”? This does not delete any music files.')
        if answer == QMessageBox.StandardButton.Yes:
            del self.playlists[name]
            self._save_state()
            self._show_page('Playlists')

    def _export_playlist(self, name=None):
        if name is None:
            from PySide6.QtWidgets import QInputDialog
            names = list(self.playlists)
            if not names:
                QMessageBox.information(self, 'No playlists', 'Create a playlist before exporting one.')
                return
            name, ok = QInputDialog.getItem(self, 'Export playlist', 'Choose a playlist:', names, 0, False)
            if not ok:
                return
        if name not in self.playlists:
            return
        path, _filter = QFileDialog.getSaveFileName(self, 'Export playlist', f'{name}.json', 'UNDERGROUND playlist (*.json)')
        if not path:
            return
        items = [self._track_by_key(key) for key in self.playlists[name]]
        payload = {'format': 'underground-playlist-v1', 'name': name, 'tracks': [asdict(track) for track in items if track]}
        try:
            Path(path).write_text(json.dumps(payload, indent=2), encoding='utf-8')
        except OSError as exc:
            QMessageBox.critical(self, 'Export failed', str(exc))
            return
        self._set_status(f'EXPORTED PLAYLIST · {name.upper()}')

    def _import_playlist(self):
        path, _filter = QFileDialog.getOpenFileName(self, 'Import playlist', '', 'UNDERGROUND playlist (*.json)')
        if not path:
            return
        try:
            payload = json.loads(Path(path).read_text(encoding='utf-8'))
            name = payload['name']
            entries = payload['tracks']
            if not isinstance(name, str) or not name.strip() or not isinstance(entries, list):
                raise ValueError('Playlist file has an invalid format.')
        except (OSError, json.JSONDecodeError, KeyError, ValueError) as exc:
            QMessageBox.critical(self, 'Import failed', str(exc))
            return
        keys = []
        known = {track.key: track for track in self.library}
        copy_failures = []
        for item in entries:
            if not isinstance(item, dict):
                continue
            raw_path = item.get('path', '')
            local_path = Path(raw_path) if isinstance(raw_path, str) and raw_path else None
            if not local_path or not local_path.is_file() or local_path.suffix.lower() not in SUPPORTED_AUDIO:
                continue
            try:
                stored_path = self._store_project_asset(local_path, MUSIC_DIR)
                track = known.get(str(stored_path.resolve()).casefold())
                if track is None:
                    track = self._track_for_file(stored_path)
                    self.library.append(track)
                    known[track.key] = track
                keys.append(track.key)
            except OSError as exc:
                copy_failures.append(f'{local_path.name}: {exc}')
        self.playlists[name.strip()] = keys
        self._save_state()
        self._show_page('Playlists')
        self._set_status(f'IMPORTED PLAYLIST · {name.upper()}')
        if copy_failures:
            QMessageBox.warning(self, 'Some playlist audio could not be copied', '\n'.join(copy_failures[:10]))

    def _show_lyrics(self):
        track = self.current_track
        if not track or not track.path:
            QMessageBox.information(self, 'Local lyrics', 'Lyrics are supported for local audio with a matching .lrc or .txt file next to the audio.')
            return
        path = Path(track.path)
        lyric = next((path.with_suffix(ext) for ext in ('.lrc', '.txt') if path.with_suffix(ext).is_file()), None)
        if not lyric:
            QMessageBox.information(self, 'No lyrics file', 'Place a .lrc or .txt file with the same name beside the audio file.')
            return
        dialog = QDialog(self)
        dialog.setWindowTitle(f'Lyrics · {track.title}')
        dialog.resize(640, 740)
        layout = QVBoxLayout(dialog)
        view = QTextEdit()
        view.setReadOnly(True)
        view.setPlainText(lyric.read_text(encoding='utf-8', errors='replace'))
        layout.addWidget(view)
        dialog.exec()

    def _search_text_changed(self, _text):
        self.search_timer.start()

    def _search(self):
        self.search_timer.stop()
        self._show_page('Your Library')

    def _focus_library_filter(self):
        if self.hud_off:
            self._set_hud_off(False)
            if hasattr(self, 'hud_checkbox'):
                self.hud_checkbox.setChecked(False)
        self._show_page('Your Library')
        self.search_box.setFocus()

    def _back(self):
        if len(self.page_stack) > 1:
            self.forward_stack.append(self.page_stack.pop())
            self._show_page(self.page_stack[-1], record_history=False)

    def _forward(self):
        if self.forward_stack:
            page = self.forward_stack.pop()
            self.page_stack.append(page)
            self._show_page(page, record_history=False)

    def _set_status(self, message):
        self.status_text = message
        if self.hud_off:
            self.statusBar().clearMessage()
        else:
            self.statusBar().showMessage(message)

    def closeEvent(self, event):
        self._save_state()
        self._timer.stop()
        if self._cursor_overridden:
            QApplication.restoreOverrideCursor()
            self._cursor_overridden = False
        if pygame.mixer.get_init():
            pygame.mixer.music.stop()
            pygame.mixer.quit()
        event.accept()


def main():
    QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
    app = QApplication(sys.argv)
    app.setApplicationName('UNDERGROUND')
    app.setWindowIcon(QIcon(str(APP_LOGO_PATH)))
    window = UndergroundWindow()
    window.show()
    if window.fullscreen_mode:
        window.showFullScreen()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()