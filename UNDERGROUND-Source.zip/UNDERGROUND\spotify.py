

from __future__ import annotations

import importlib.util
import re
import shutil
import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import QThread, Qt, QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

try:
    from PySide6.QtWebEngineCore import (
        QWebEnginePage,
        QWebEngineProfile,
        QWebEngineSettings,
    )
    from PySide6.QtWebEngineWidgets import QWebEngineView
    WEBENGINE_AVAILABLE = True
    WEBENGINE_ERROR = ''
except Exception as exc:
    WEBENGINE_AVAILABLE = False
    WEBENGINE_ERROR = str(exc)


AUDIO_SUFFIXES = {'.mp3', '.wav', '.ogg'}
_DESKTOP_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
)
_KINDS = 'track|album|playlist|artist|episode|show'
_URI_RE = re.compile(rf'^spotify:({_KINDS}):([A-Za-z0-9]{{22}})$', re.IGNORECASE)
_WEB_RE = re.compile(
    rf'^(?:https?://)?(?:open|play)\.spotify\.com/'
    rf'(?:intl-[a-z]{{2}}(?:-[A-Z]{{2}})?/)?({_KINDS})/([A-Za-z0-9]{{22}})',
    re.IGNORECASE,
)
_BARE_ID = re.compile(r'^[A-Za-z0-9]{22}$')


def parse_spotify_reference(raw):
    """Return (kind, spotify_id) for any Spotify link, URI, or bare ID."""
    text = (raw or '').strip()
    if not text:
        raise ValueError('Paste a Spotify track, album, or playlist link first.')
    match = _URI_RE.match(text)
    if match:
        return match.group(1).lower(), match.group(2)
    match = _WEB_RE.match(text)
    if match:
        return match.group(1).lower(), match.group(2)
    if _BARE_ID.match(text):
        return 'track', text
    raise ValueError(
        'That is not a Spotify link. Use Share -> Copy link in Spotify.'
    )


def canonical_url(kind, spotify_id):
    return f'https://open.spotify.com/{kind}/{spotify_id}'


def embed_url(kind, spotify_id):
    return (
        f'https://open.spotify.com/embed/{kind}/{spotify_id}'
        '?utm_source=generator&theme=0'
    )


def spotdl_command():
    executable = shutil.which('spotdl')
    if executable:
        return [executable]
    if not getattr(sys, 'frozen', False) and importlib.util.find_spec('spotdl'):
        return [sys.executable, '-m', 'spotdl']
    return []


class SpotifyTaskWorker(QThread):
    """Runs a command, streams its output, and collects new audio files."""

    progress = Signal(str)
    completed = Signal(list, str)

    def __init__(self, command, watch_dir=None, parent=None):
        super().__init__(parent)
        self.command = list(command)
        self.watch_dir = Path(watch_dir) if watch_dir else None

    def run(self):
        before = set()
        if self.watch_dir:
            self.watch_dir.mkdir(parents=True, exist_ok=True)
            before = {p.resolve() for p in self.watch_dir.rglob('*') if p.is_file()}
        try:
            process = subprocess.Popen(
                self.command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding='utf-8',
                errors='replace',
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
            )
        except OSError as exc:
            self.completed.emit([], f'Could not start the command: {exc}')
            return
        self._process = process
        for line in process.stdout:
            if self.isInterruptionRequested():
                process.terminate()
                break
            line = line.strip()
            if line:
                self.progress.emit(line[:180])
        code = process.wait()
        found = []
        if self.watch_dir:
            found = [
                str(path)
                for path in self.watch_dir.rglob('*')
                if path.is_file()
                and path.suffix.lower() in AUDIO_SUFFIXES
                and path.resolve() not in before
            ]
        if self.isInterruptionRequested():
            self.completed.emit(found, 'Download canceled.')
        elif code != 0 and not found:
            self.completed.emit([], f'The command exited with code {code}.')
        else:
            self.completed.emit(found, '')


class SpotifyPanel(QWidget):
    status_message = Signal(str)
    files_downloaded = Signal(list)

    def __init__(self, parent=None, app_dir=None):
        super().__init__(parent)
        self.app_dir = Path(app_dir) if app_dir else Path.home() / 'UNDERGROUND'
        self.view = None
        self.profile = None
        self.web_page = None
        self.worker = None
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        kicker = QLabel('SPOTIFY')
        kicker.setStyleSheet('font-size:9px;font-weight:800;letter-spacing:1.5px;')
        layout.addWidget(kicker)

        heading = QLabel('Paste a link. It plays here.')
        heading.setWordWrap(True)
        heading.setStyleSheet('font-size:27px;font-weight:800;letter-spacing:-1px;')
        layout.addWidget(heading)

        self.status_label = QLabel(
            'Track, album, and playlist links all work. Log in inside this panel '
            'once and the session is remembered - Premium accounts get full songs '
            'without ads. SAVE TO LIBRARY downloads the real audio instead.'
        )
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet('font-size:11px;')
        layout.addWidget(self.status_label)

        url_row = QHBoxLayout()
        self.url_box = QLineEdit()
        self.url_box.setObjectName('searchBox')
        self.url_box.setPlaceholderText(
            'https://open.spotify.com/track/...   or   spotify:album:...'
        )
        self.url_box.returnPressed.connect(self.play)
        url_row.addWidget(self.url_box, 1)
        play = QPushButton('PLAY')
        play.setObjectName('accentButton')
        play.setCursor(Qt.CursorShape.PointingHandCursor)
        play.clicked.connect(self.play)
        url_row.addWidget(play)
        layout.addLayout(url_row)

        action_row = QHBoxLayout()
        for label, slot in (
            ('OPEN IN SPOTIFY', self.open_external),
            ('SAVE TO LIBRARY', self.save_to_library),
            ('RELOAD', self.reload),
            ('CLEAR', self.clear),
        ):
            button = QPushButton(label)
            button.setObjectName('secondaryButton')
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(slot)
            action_row.addWidget(button)
        action_row.addStretch(1)
        layout.addLayout(action_row)

        if not WEBENGINE_AVAILABLE:
            note = QLabel(
                'The embedded player needs QtWebEngine, which ships with '
                'PySide6-Addons.\n' f'pip install PySide6-Addons\n\n{WEBENGINE_ERROR}'
            )
            note.setWordWrap(True)
            layout.addWidget(note)
            layout.addStretch(1)

    def _ensure_view(self):
        if self.view is not None or not WEBENGINE_AVAILABLE:
            return self.view
        storage = self.app_dir / 'spotify'
        profile = QWebEngineProfile('underground-spotify', self)
        profile.setPersistentStoragePath(str(storage / 'storage'))
        profile.setCachePath(str(storage / 'cache'))
        profile.setPersistentCookiesPolicy(
            QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies
        )
        profile.setHttpUserAgent(_DESKTOP_UA)
        self.profile = profile

        view = QWebEngineView(self)
        page = QWebEnginePage(profile, view)
        view.setPage(page)
        self.web_page = page
        settings = view.settings()
        settings.setAttribute(
            QWebEngineSettings.WebAttribute.PlaybackRequiresUserGesture, False
        )
        settings.setAttribute(
            QWebEngineSettings.WebAttribute.JavascriptCanOpenWindows, True
        )
        view.setMinimumHeight(300)
        self.layout().addWidget(view, 1)
        self.view = view
        return view

    def _report(self, message):
        self.status_label.setText(message)
        self.status_message.emit(message.upper())

    def play(self, *_args):
        try:
            kind, spotify_id = parse_spotify_reference(self.url_box.text())
        except ValueError as exc:
            self._report(str(exc))
            return
        self.url_box.setText(canonical_url(kind, spotify_id))
        if not WEBENGINE_AVAILABLE:
            QDesktopServices.openUrl(QUrl(canonical_url(kind, spotify_id)))
            self._report('Opened in your browser.')
            return
        view = self._ensure_view()
        view.setUrl(QUrl(embed_url(kind, spotify_id)))
        self._report(f'Loading {kind} {spotify_id}.')

    def open_external(self, *_args):
        try:
            kind, spotify_id = parse_spotify_reference(self.url_box.text())
        except ValueError as exc:
            self._report(str(exc))
            return
        QDesktopServices.openUrl(QUrl(canonical_url(kind, spotify_id)))

    def reload(self, *_args):
        if self.view is not None:
            self.view.reload()

    def clear(self, *_args):
        self.url_box.clear()
        if self.view is not None:
            self.view.setUrl(QUrl('about:blank'))
        self._report('Cleared.')

    def save_to_library(self, *_args):
        if self.worker is not None and self.worker.isRunning():
            self._report('A Spotify download is already running.')
            return
        try:
            kind, spotify_id = parse_spotify_reference(self.url_box.text())
        except ValueError as exc:
            self._report(str(exc))
            return
        if kind in ('artist', 'show'):
            self._report('Use an album, playlist, or track link to save audio.')
            return
        command = spotdl_command()
        if not command:
            self._offer_install()
            return
        if not shutil.which('ffmpeg'):
            self._report(
                'ffmpeg is not on PATH - spotdl needs it to convert audio.'
            )
        target = self.app_dir / 'spotify-downloads'
        full = command + [
            'download',
            canonical_url(kind, spotify_id),
            '--output',
            str(target / '{artist} - {title}.{output-ext}'),
            '--format',
            'mp3',
            '--bitrate',
            '320k',
            '--threads',
            '2',
            '--overwrite',
            'skip',
        ]
        self.worker = SpotifyTaskWorker(full, target, self)
        self.worker.progress.connect(self._report)
        self.worker.completed.connect(self._download_finished)
        self.worker.start()
        self._report('Downloading to your library - this takes a while.')

    def _download_finished(self, files, error):
        if error and error != 'Download canceled.':
            QMessageBox.warning(self, 'Spotify download failed', error)
            self._report(error)
        elif files:
            self._report(f'Fetched {len(files)} track(s). Importing.')
            self.files_downloaded.emit(files)
        else:
            self._report('Nothing was downloaded.')
        if self.worker is not None:
            self.worker.deleteLater()
            self.worker = None

    def _offer_install(self):
        if getattr(sys, 'frozen', False):
            detail = (
                'spotdl was not found. The built app cannot install it itself - '
                'open a terminal and run:\n\n    pip install spotdl\n\n'
                'Then restart UNDERGROUND.'
            )
            QMessageBox.information(self, 'spotdl is not installed', detail)
            return
        answer = QMessageBox.question(
            self,
            'spotdl is not installed',
            'Saving full audio needs spotdl. Install it with:\n\n'
            f'    "{sys.executable}" -m pip install spotdl\n\n'
            'ffmpeg must also be on PATH. Install now?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.worker = SpotifyTaskWorker(
            [sys.executable, '-m', 'pip', 'install', 'spotdl'], None, self
        )
        self.worker.progress.connect(self._report)
        self.worker.completed.connect(self._install_finished)
        self.worker.start()
        self._report('Installing spotdl...')

    def _install_finished(self, _files, error):
        if error:
            QMessageBox.warning(self, 'spotdl install failed', error)
            self._report(error)
        else:
            self._report('spotdl installed. Press SAVE TO LIBRARY again.')
        if self.worker is not None:
            self.worker.deleteLater()
            self.worker = None
def _preview():
    import sys

    from PySide6.QtWidgets import QApplication, QMainWindow

    QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
    app = QApplication(sys.argv)
    window = QMainWindow()
    window.setWindowTitle('Spotify panel - preview')
    window.resize(1000, 720)
    panel = SpotifyPanel(app_dir=Path.home() / 'UNDERGROUND')
    window.setCentralWidget(panel)
    window.setStyleSheet(
        'QMainWindow { background:#17120f; }'
        'QLabel { color:#fff2e4; }'
        'QLineEdit#searchBox { background:#120f0e; color:#fff2e4;'
        ' border:1px solid #3a332c; border-radius:8px; padding:7px 11px; }'
        'QPushButton#accentButton { background:#b69cff; color:#15110e; border:0;'
        ' border-radius:6px; padding:8px 12px; font-weight:800; }'
        'QPushButton#secondaryButton { background:#241d18; color:#fff2e4;'
        ' border:1px solid #3a332c; border-radius:7px; padding:8px 11px; font-size:11px; }'
    )
    window.show()
    app.exec()


if __name__ == '__main__':
    _preview()