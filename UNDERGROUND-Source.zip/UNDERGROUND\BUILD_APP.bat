@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo -
echo   UNDERGROUND  -  build
echo -
echo.

set "PYTHON="
for %%V in (3.13 3.12 3.11 3.10) do (
    if not defined PYTHON (
        py -%%V -c "import sys" >nul 2>&1
        if not errorlevel 1 set "PYTHON=py -%%V"
    )
)
if not defined PYTHON (
    py -3 -c "import sys" >nul 2>&1
    if not errorlevel 1 set "PYTHON=py -3"
)
if not defined PYTHON (
    python -c "import sys" >nul 2>&1
    if not errorlevel 1 set "PYTHON=python"
)
if not defined PYTHON goto :nopython

for /f "delims=" %%P in ('%PYTHON% -c "import sys; print(sys.version.split()[0])"') do set "PYVER=%%P"
echo Using Python %PYVER%  ^(%PYTHON%^)

%PYTHON% -c "import sys; sys.exit(0 if sys.version_info < (3, 14) else 1)" >nul 2>&1
if errorlevel 1 (
    echo.
    echo Python %PYVER% is too new - PySide6 has no wheels for it yet.
    echo Install 3.12 or 3.13 and run this again.
    echo.
    pause
    exit /b 1
)
echo.

if not exist "requirements-build.txt" (
    echo requirements-build.txt is missing.
    pause
    exit /b 1
)

echo Installing build requirements...
%PYTHON% -m pip install --upgrade pip setuptools wheel
%PYTHON% -m pip install -r requirements-build.txt
if errorlevel 1 goto :failed

echo.
echo Verifying QtWebEngine is importable...
%PYTHON% -c "from PySide6.QtWebEngineWidgets import QWebEngineView" >nul 2>&1
if errorlevel 1 (
    echo QtWebEngine is missing from this Python.
    echo Run:  %PYTHON% -m pip install --force-reinstall PySide6-Addons
    goto :failed
)

echo.
echo Building...
%PYTHON% -m PyInstaller --noconfirm --clean --windowed --onedir --name UNDERGROUND --icon "%~dp0assets\underground.ico" --add-data "%~dp0assets\underground-logo.png;assets" --collect-all pygame --collect-all mutagen --collect-all PySide6.QtWebEngineCore --collect-all PySide6.QtWebEngineWidgets --hidden-import PySide6.QtWebEngineCore --hidden-import PySide6.QtWebEngineWidgets --distpath "%~dp0dist" --workpath "%TEMP%\UNDERGROUND-pyinstaller-build" --specpath "%TEMP%\UNDERGROUND-pyinstaller-spec" main.py
if errorlevel 1 goto :failed

echo.                  
echo
echo
echo
echo.
pause
exit /b 0

:nopython
echo.
echo Python was not found.
echo.
echo Install Python 3.12 or 3.13:
echo   https://www.python.org/downloads/windows/
echo Tick "Add python.exe to PATH" during setup, then run this again.
echo.
pause
exit /b 1

:failed
echo.
echo Build failed. Review the error above.
echo.
pause
exit /b 1